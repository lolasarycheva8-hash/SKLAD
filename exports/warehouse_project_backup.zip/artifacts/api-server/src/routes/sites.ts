import { Router, type IRouter } from "express";
import { eq, ilike } from "drizzle-orm";
import { db, sitesTable } from "@workspace/db";
import {
  ListSitesQueryParams,
  CreateSiteBody,
  GetSiteParams,
  UpdateSiteParams,
  UpdateSiteBody,
  DeleteSiteParams,
  ListSitesResponse,
  CreateSiteResponse,
  GetSiteResponse,
  UpdateSiteResponse,
  CreateSitesBulkBody,
  CreateSitesBulkResponse,
} from "@workspace/api-zod";
import { requirePermission } from "../middlewares/requirePermission";

const router: IRouter = Router();
const canEditSites = requirePermission("sites");

function toSiteDto(row: typeof sitesTable.$inferSelect) {
  return {
    id: row.id,
    name: row.name,
    address: row.address,
    branch: row.branch,
    customer: row.customer,
    client: row.client,
    manager: row.manager,
    director: row.director,
    project: row.project,
    driver: row.driver,
    storeArea: Number(row.storeArea),
    createdAt: row.createdAt,
  };
}

router.get("/sites", async (req, res): Promise<void> => {
  const query = ListSitesQueryParams.safeParse(req.query);
  if (!query.success) {
    res.status(400).json({ error: query.error.message });
    return;
  }

  const rows = await db
    .select()
    .from(sitesTable)
    .where(query.data.search ? ilike(sitesTable.name, `%${query.data.search}%`) : undefined)
    .orderBy(sitesTable.name);

  res.json(ListSitesResponse.parse(rows.map(toSiteDto)));
});

router.post("/sites", canEditSites, async (req, res): Promise<void> => {
  const parsed = CreateSiteBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [existing] = await db
    .select()
    .from(sitesTable)
    .where(eq(sitesTable.name, parsed.data.name));

  if (existing) {
    res.status(409).json({ error: "Объект с таким названием уже существует" });
    return;
  }

  const [site] = await db
    .insert(sitesTable)
    .values({
      name: parsed.data.name,
      address: parsed.data.address,
      branch: parsed.data.branch,
      customer: parsed.data.customer,
      client: parsed.data.client,
      manager: parsed.data.manager,
      director: parsed.data.director,
      project: parsed.data.project,
      driver: parsed.data.driver,
      storeArea: String(parsed.data.storeArea),
    })
    .returning();

  res.status(201).json(CreateSiteResponse.parse(toSiteDto(site)));
});

router.post("/sites/bulk", canEditSites, async (req, res): Promise<void> => {
  const parsed = CreateSitesBulkBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const results: ReturnType<typeof toSiteDto>[] = [];

  for (const item of parsed.data.items) {
    const [existing] = await db
      .select()
      .from(sitesTable)
      .where(eq(sitesTable.name, item.name));

    const values = {
      name: item.name,
      address: item.address,
      branch: item.branch,
      customer: item.customer,
      client: item.client,
      manager: item.manager,
      director: item.director,
      project: item.project,
      driver: item.driver,
      storeArea: String(item.storeArea),
    };

    let site;
    if (existing) {
      [site] = await db
        .update(sitesTable)
        .set(values)
        .where(eq(sitesTable.id, existing.id))
        .returning();
    } else {
      [site] = await db.insert(sitesTable).values(values).returning();
    }

    results.push(toSiteDto(site));
  }

  res.status(201).json(CreateSitesBulkResponse.parse(results));
});

router.get("/sites/:id", async (req, res): Promise<void> => {
  const params = GetSiteParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [site] = await db.select().from(sitesTable).where(eq(sitesTable.id, params.data.id));

  if (!site) {
    res.status(404).json({ error: "Site not found" });
    return;
  }

  res.json(GetSiteResponse.parse(toSiteDto(site)));
});

router.patch("/sites/:id", canEditSites, async (req, res): Promise<void> => {
  const params = UpdateSiteParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const parsed = UpdateSiteBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  if (parsed.data.name) {
    const [existing] = await db
      .select()
      .from(sitesTable)
      .where(eq(sitesTable.name, parsed.data.name));
    if (existing && existing.id !== params.data.id) {
      res.status(409).json({ error: "Объект с таким названием уже существует" });
      return;
    }
  }

  const updateValues: Record<string, unknown> = {};
  if (parsed.data.name !== undefined) updateValues.name = parsed.data.name;
  if (parsed.data.address !== undefined) updateValues.address = parsed.data.address;
  if (parsed.data.branch !== undefined) updateValues.branch = parsed.data.branch;
  if (parsed.data.customer !== undefined) updateValues.customer = parsed.data.customer;
  if (parsed.data.client !== undefined) updateValues.client = parsed.data.client;
  if (parsed.data.manager !== undefined) updateValues.manager = parsed.data.manager;
  if (parsed.data.director !== undefined) updateValues.director = parsed.data.director;
  if (parsed.data.project !== undefined) updateValues.project = parsed.data.project;
  if (parsed.data.driver !== undefined) updateValues.driver = parsed.data.driver;
  if (parsed.data.storeArea !== undefined) updateValues.storeArea = String(parsed.data.storeArea);

  const [site] = await db
    .update(sitesTable)
    .set(updateValues)
    .where(eq(sitesTable.id, params.data.id))
    .returning();

  if (!site) {
    res.status(404).json({ error: "Site not found" });
    return;
  }

  res.json(UpdateSiteResponse.parse(toSiteDto(site)));
});

router.delete("/sites/:id", canEditSites, async (req, res): Promise<void> => {
  const params = DeleteSiteParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [site] = await db
    .delete(sitesTable)
    .where(eq(sitesTable.id, params.data.id))
    .returning();

  if (!site) {
    res.status(404).json({ error: "Site not found" });
    return;
  }

  res.sendStatus(204);
});

export default router;
