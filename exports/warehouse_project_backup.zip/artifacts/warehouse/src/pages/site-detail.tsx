import { useEffect, useState } from "react";
import { useParams, useLocation } from "wouter";
import { useQueryClient } from "@tanstack/react-query";
import {
  useGetSite,
  useUpdateSite,
  getListSitesQueryKey,
  getGetSiteQueryKey,
} from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ArrowLeft } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { usePermissions } from "@/hooks/use-permissions";

type FormState = {
  branch: string;
  customer: string;
  client: string;
  manager: string;
  director: string;
  project: string;
  driver: string;
  storeArea: string;
};

export default function SiteDetail() {
  const params = useParams<{ id: string }>();
  const [, setLocation] = useLocation();
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const { canEdit } = usePermissions();
  const canEditSites = canEdit("sites");

  const { data: site, isLoading } = useGetSite(params.id);
  const [form, setForm] = useState<FormState | null>(null);

  useEffect(() => {
    if (site) {
      setForm({
        branch: site.branch,
        customer: site.customer,
        client: site.client,
        manager: site.manager,
        director: site.director,
        project: site.project,
        driver: site.driver,
        storeArea: String(site.storeArea),
      });
    }
  }, [site]);

  const updateSite = useUpdateSite({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListSitesQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetSiteQueryKey(params.id) });
        toast({ title: "Объект обновлён" });
      },
      onError: (error) => {
        toast({ title: "Ошибка", description: error.message, variant: "destructive" });
      },
    },
  });

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!form) return;

    updateSite.mutate({
      id: params.id,
      data: {
        branch: form.branch,
        customer: form.customer,
        client: form.client,
        manager: form.manager,
        director: form.director,
        project: form.project,
        driver: form.driver,
        storeArea: Number(form.storeArea),
      },
    });
  }

  if (isLoading || !site || !form) {
    return (
      <div className="space-y-6">
        <Button variant="ghost" onClick={() => setLocation("/sites")} data-testid="button-back-sites">
          <ArrowLeft className="h-4 w-4 mr-2" />
          Назад к объектам
        </Button>
        <p className="text-muted-foreground text-sm">Загрузка...</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <Button variant="ghost" onClick={() => setLocation("/sites")} data-testid="button-back-sites">
          <ArrowLeft className="h-4 w-4 mr-2" />
          Назад к объектам
        </Button>
        <h1 className="text-2xl font-bold text-blue-900 bg-[#f5ecd9] rounded-md px-4 py-2 block w-full mt-2" data-testid="text-page-title">
          {site.name}
        </h1>
        <p className="text-muted-foreground text-sm mt-1">{site.address}</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Данные объекта</CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="name">Название</Label>
                <Input id="name" value={site.name} disabled data-testid="input-site-name" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="address">Адрес</Label>
                <Input id="address" value={site.address} disabled data-testid="input-site-address" />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="branch">Филиал</Label>
                <Input
                  id="branch"
                  required
                  disabled={!canEditSites}
                  value={form.branch}
                  onChange={(e) => setForm({ ...form, branch: e.target.value })}
                  data-testid="input-site-branch"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="client">Клиент</Label>
                <Input
                  id="client"
                  required
                  disabled={!canEditSites}
                  value={form.client}
                  onChange={(e) => setForm({ ...form, client: e.target.value })}
                  data-testid="input-site-client"
                />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="customer">Заказчик</Label>
                <Input
                  id="customer"
                  required
                  disabled={!canEditSites}
                  value={form.customer}
                  onChange={(e) => setForm({ ...form, customer: e.target.value })}
                  data-testid="input-site-customer"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="manager">Закреплённый менеджер</Label>
                <Input
                  id="manager"
                  required
                  disabled={!canEditSites}
                  value={form.manager}
                  onChange={(e) => setForm({ ...form, manager: e.target.value })}
                  data-testid="input-site-manager"
                />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="director">Закреплённый руководитель</Label>
                <Input
                  id="director"
                  required
                  disabled={!canEditSites}
                  value={form.director}
                  onChange={(e) => setForm({ ...form, director: e.target.value })}
                  data-testid="input-site-director"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="project">Закреплённый проект</Label>
                <Input
                  id="project"
                  required
                  disabled={!canEditSites}
                  value={form.project}
                  onChange={(e) => setForm({ ...form, project: e.target.value })}
                  data-testid="input-site-project"
                />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="driver">Закреплённый водитель</Label>
                <Input
                  id="driver"
                  required
                  disabled={!canEditSites}
                  value={form.driver}
                  onChange={(e) => setForm({ ...form, driver: e.target.value })}
                  data-testid="input-site-driver"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="storeArea">Площадь магазина, м²</Label>
                <Input
                  id="storeArea"
                  type="number"
                  min="0"
                  step="0.01"
                  required
                  disabled={!canEditSites}
                  value={form.storeArea}
                  onChange={(e) => setForm({ ...form, storeArea: e.target.value })}
                  data-testid="input-site-store-area"
                />
              </div>
            </div>
            {canEditSites && (
              <Button type="submit" disabled={updateSite.isPending} data-testid="button-submit-site">
                Сохранить
              </Button>
            )}
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
