import type { NextFunction, Request, Response } from "express";
import { getAuth, clerkClient } from "@clerk/express";
import { eq, sql } from "drizzle-orm";
import { db, appUsersTable, type AppUser } from "@workspace/db";

declare global {
  namespace Express {
    interface Request {
      appUser?: AppUser;
    }
  }
}

async function provisionAppUser(clerkUserId: string): Promise<AppUser> {
  const [existing] = await db
    .select()
    .from(appUsersTable)
    .where(eq(appUsersTable.clerkUserId, clerkUserId));

  if (existing) {
    return existing;
  }

  const clerkUser = await clerkClient.users.getUser(clerkUserId);
  const email = clerkUser.emailAddresses.find(
    (e) => e.id === clerkUser.primaryEmailAddressId,
  )?.emailAddress ?? clerkUser.emailAddresses[0]?.emailAddress ?? "";
  const name =
    [clerkUser.firstName, clerkUser.lastName].filter(Boolean).join(" ") || null;

  const [{ count }] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(appUsersTable);
  const isFirstUser = count === 0;

  const [created] = await db
    .insert(appUsersTable)
    .values({
      clerkUserId,
      email,
      name,
      role: isFirstUser ? "admin" : "viewer",
      editableSections: [],
    })
    .onConflictDoNothing({ target: appUsersTable.clerkUserId })
    .returning();

  if (created) {
    return created;
  }

  // Concurrent request already inserted it; fetch it.
  const [row] = await db
    .select()
    .from(appUsersTable)
    .where(eq(appUsersTable.clerkUserId, clerkUserId));
  return row;
}

const DEV_BYPASS_CLERK_USER_ID = "dev-bypass-user";

// TEMPORARY: lets us build/test the app without going through Clerk sign-in.
// Only takes effect when DISABLE_AUTH=true, which is only set in the
// development environment. Remove this block (and the DISABLE_AUTH env var)
// before relying on real auth again — e.g. before testing login in production.
async function provisionDevBypassUser(): Promise<AppUser> {
  const [existing] = await db
    .select()
    .from(appUsersTable)
    .where(eq(appUsersTable.clerkUserId, DEV_BYPASS_CLERK_USER_ID));

  if (existing) {
    return existing;
  }

  const [created] = await db
    .insert(appUsersTable)
    .values({
      clerkUserId: DEV_BYPASS_CLERK_USER_ID,
      email: "dev-bypass@local",
      name: "Dev Bypass (auth disabled)",
      role: "admin",
      editableSections: [],
    })
    .onConflictDoNothing({ target: appUsersTable.clerkUserId })
    .returning();

  if (created) {
    return created;
  }

  const [row] = await db
    .select()
    .from(appUsersTable)
    .where(eq(appUsersTable.clerkUserId, DEV_BYPASS_CLERK_USER_ID));
  return row;
}

export async function requireAuth(
  req: Request,
  res: Response,
  next: NextFunction,
): Promise<void> {
  if (process.env.DISABLE_AUTH === "true") {
    try {
      req.appUser = await provisionDevBypassUser();
    } catch (err) {
      req.log?.error({ err }, "Failed to provision dev bypass user");
      res.status(500).json({ error: "Failed to resolve user" });
      return;
    }
    next();
    return;
  }

  const auth = getAuth(req);
  const userId = (auth?.sessionClaims?.userId as string | undefined) || auth?.userId;
  if (!userId) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }

  try {
    req.appUser = await provisionAppUser(userId);
  } catch (err) {
    req.log?.error({ err }, "Failed to provision app user");
    res.status(500).json({ error: "Failed to resolve user" });
    return;
  }

  next();
}
