import { Link, useLocation } from "wouter";
import {
  Package,
  LayoutDashboard,
  PackagePlus,
  Warehouse,
  Building2,
  Truck,
  Users,
  ClipboardList,
  Send,
  ShieldCheck,
  Tag,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { usePermissions } from "@/hooks/use-permissions";

const NAV_ITEMS = [
  { href: "/", label: "Сводный отчет", icon: LayoutDashboard },
  { href: "/shipments", label: "Отгрузки", icon: Send },
  { href: "/orders", label: "Заказы клиентов", icon: ClipboardList },
  { href: "/deliveries", label: "График доставок", icon: Truck },
  { href: "/receipts", label: "Поступление товара", icon: PackagePlus },
  { href: "/clients", label: "Клиенты", icon: Users },
  { href: "/sites", label: "Объекты", icon: Building2 },
  { href: "/products", label: "Товары", icon: Package },
  { href: "/categories", label: "Категории", icon: Tag },
];

const ADMIN_NAV_ITEM = { href: "/users", label: "Пользователи", icon: ShieldCheck };

export function Layout({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();
  const { isAdmin } = usePermissions();
  const navItems = isAdmin ? [...NAV_ITEMS, ADMIN_NAV_ITEM] : NAV_ITEMS;

  return (
    <div className="min-h-screen flex bg-background">
      <aside className="w-64 shrink-0 bg-sidebar text-sidebar-foreground border-r border-sidebar-border flex flex-col">
        <div className="h-16 flex items-center gap-2 px-5 border-b border-sidebar-border">
          <Warehouse className="h-6 w-6 text-sidebar-primary" />
          <span className="font-bold text-lg text-white">Склад</span>
        </div>
        <nav className="flex-1 px-3 py-4 space-y-1">
          {navItems.map((item) => {
            const isActive =
              location === item.href || (item.href !== "/" && location.startsWith(item.href + "/"));
            const Icon = item.icon;
            return (
              <Link
                key={item.href}
                href={item.href}
                data-testid={`link-nav-${item.href === "/" ? "dashboard" : item.href.slice(1)}`}
                className={cn(
                  "flex items-center gap-3 rounded-md px-3 py-2 text-sm font-medium transition-colors",
                  isActive
                    ? "bg-sidebar-primary text-sidebar-primary-foreground"
                    : "text-sidebar-foreground/80 hover:bg-sidebar-accent hover:text-sidebar-accent-foreground",
                )}
              >
                <Icon className="h-4 w-4" />
                {item.label}
              </Link>
            );
          })}
        </nav>
        <div className="px-5 py-4 border-t border-sidebar-border text-xs text-sidebar-foreground/50">
          Складской учёт v1.0
        </div>
      </aside>
      <main className="flex-1 min-w-0">
        <div className="max-w-6xl mx-auto px-6 py-8">{children}</div>
      </main>
    </div>
  );
}
