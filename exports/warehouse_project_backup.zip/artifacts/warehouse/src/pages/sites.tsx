import { useMemo, useRef, useState } from "react";
import { useLocation } from "wouter";
import { useQueryClient } from "@tanstack/react-query";
import {
  useListSites,
  useCreateSite,
  useDeleteSite,
  useCreateSitesBulk,
  getListSitesQueryKey,
} from "@workspace/api-client-react";
import type { Site } from "@workspace/api-client-react";
import {
  parseExcelFile,
  readSheetHeaders,
  validateTemplateHeaders,
  downloadTemplate,
  exportRowsToExcel,
  str,
  num,
} from "@/lib/excel-import";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import {
  SortableHeader,
  type SortDirection,
} from "@/components/sortable-header";
import {
  Plus,
  Pencil,
  Trash2,
  Search,
  Upload,
  Download,
  FileDown,
  Filter,
  X,
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { usePermissions } from "@/hooks/use-permissions";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

type FormState = {
  name: string;
  address: string;
  branch: string;
  customer: string;
  client: string;
  manager: string;
  director: string;
  project: string;
  driver: string;
  storeArea: string;
};

const EMPTY_FORM: FormState = {
  name: "",
  address: "",
  branch: "",
  customer: "",
  client: "",
  manager: "",
  director: "",
  project: "",
  driver: "",
  storeArea: "",
};

const TEMPLATE_HEADERS = [
  "Название",
  "Адрес",
  "Филиал",
  "Заказчик",
  "Клиент",
  "Менеджер",
  "Руководитель",
  "Проект",
  "Водитель",
  "Площадь, м²",
];

const FILTER_FIELDS: { key: keyof Site; label: string }[] = [
  { key: "branch", label: "Филиал" },
  { key: "customer", label: "Заказчик" },
  { key: "client", label: "Клиент" },
  { key: "manager", label: "Менеджер" },
  { key: "director", label: "Руководитель" },
  { key: "project", label: "Проект" },
  { key: "driver", label: "Водитель" },
];

type SortField =
  | "name"
  | "address"
  | "branch"
  | "customer"
  | "client"
  | "manager"
  | "director"
  | "project"
  | "driver"
  | "storeArea"
  | "createdAt";

const dateFormatter = new Intl.DateTimeFormat("ru-RU", {
  day: "2-digit",
  month: "2-digit",
  year: "numeric",
});

export default function Sites() {
  const [, setLocation] = useLocation();
  const [search, setSearch] = useState("");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [form, setForm] = useState<FormState>(EMPTY_FORM);
  const [deleteTarget, setDeleteTarget] = useState<Site | null>(null);
  const [fieldFilters, setFieldFilters] = useState<Record<string, string>>({});
  const [sortField, setSortField] = useState<SortField>("name");
  const [sortDir, setSortDir] = useState<SortDirection>("asc");

  const queryClient = useQueryClient();
  const { toast } = useToast();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { canEdit } = usePermissions();
  const canEditSites = canEdit("sites");

  const { data: sites, isLoading } = useListSites({
    search: search || undefined,
  });

  const filteredSites = useMemo(() => {
    const filtered = (sites ?? []).filter((site) =>
      FILTER_FIELDS.every(({ key }) => {
        const value = fieldFilters[key];
        if (!value) return true;
        return String(site[key] ?? "")
          .toLowerCase()
          .includes(value.toLowerCase());
      }),
    );

    const dir = sortDir === "asc" ? 1 : -1;
    return [...filtered].sort((a, b) => {
      switch (sortField) {
        case "name":
          return a.name.localeCompare(b.name, "ru") * dir;
        case "address":
          return a.address.localeCompare(b.address, "ru") * dir;
        case "branch":
          return a.branch.localeCompare(b.branch, "ru") * dir;
        case "customer":
          return a.customer.localeCompare(b.customer, "ru") * dir;
        case "client":
          return a.client.localeCompare(b.client, "ru") * dir;
        case "manager":
          return a.manager.localeCompare(b.manager, "ru") * dir;
        case "director":
          return a.director.localeCompare(b.director, "ru") * dir;
        case "project":
          return a.project.localeCompare(b.project, "ru") * dir;
        case "driver":
          return a.driver.localeCompare(b.driver, "ru") * dir;
        case "storeArea":
          return (a.storeArea - b.storeArea) * dir;
        case "createdAt":
          return (
            (new Date(a.createdAt).getTime() -
              new Date(b.createdAt).getTime()) *
            dir
          );
        default:
          return 0;
      }
    });
  }, [sites, fieldFilters, sortField, sortDir]);

  function handleSort(field: SortField) {
    if (field === sortField) {
      setSortDir((d) => (d === "asc" ? "desc" : "asc"));
    } else {
      setSortField(field);
      setSortDir("asc");
    }
  }

  const activeFilterCount = Object.values(fieldFilters).filter(Boolean).length;
  const hasActiveFilters = activeFilterCount > 0;

  const invalidate = () => {
    queryClient.invalidateQueries({ queryKey: getListSitesQueryKey() });
  };

  const createSite = useCreateSite({
    mutation: {
      onSuccess: () => {
        invalidate();
        setDialogOpen(false);
        toast({ title: "Объект добавлен" });
      },
      onError: (error) => {
        toast({
          title: "Ошибка",
          description: error.message,
          variant: "destructive",
        });
      },
    },
  });

  const deleteSite = useDeleteSite({
    mutation: {
      onSuccess: () => {
        invalidate();
        setDeleteTarget(null);
        toast({ title: "Объект удалён" });
      },
      onError: (error) => {
        toast({
          title: "Ошибка",
          description: error.message,
          variant: "destructive",
        });
      },
    },
  });

  const createSitesBulk = useCreateSitesBulk({
    mutation: {
      onSuccess: (data) => {
        invalidate();
        toast({
          title: "Импорт завершён",
          description: `Обработано объектов: ${data.length}`,
        });
      },
      onError: (error) => {
        toast({
          title: "Ошибка импорта",
          description: error.message,
          variant: "destructive",
        });
      },
    },
  });

  async function handleImportFile(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    e.target.value = "";
    if (!file) return;

    try {
      const headers = await readSheetHeaders(file);
      const missing = validateTemplateHeaders(headers, TEMPLATE_HEADERS);
      if (missing.length > 0) {
        toast({
          title: "Файл не соответствует шаблону",
          description: `Отсутствуют колонки: ${missing.join(", ")}`,
          variant: "destructive",
        });
        return;
      }

      const rows = await parseExcelFile(file);
      const items = rows.map((row) => ({
        name: str(row["Название"]),
        address: str(row["Адрес"]),
        branch: str(row["Филиал"]),
        customer: str(row["Заказчик"]),
        client: str(row["Клиент"]),
        manager: str(row["Менеджер"]),
        director: str(row["Руководитель"]),
        project: str(row["Проект"]),
        driver: str(row["Водитель"]),
        storeArea: num(row["Площадь, м²"]),
      }));

      if (items.length === 0) {
        toast({ title: "Файл пуст", variant: "destructive" });
        return;
      }

      createSitesBulk.mutate({ data: { items } });
    } catch (error) {
      toast({
        title: "Не удалось прочитать файл",
        description: error instanceof Error ? error.message : String(error),
        variant: "destructive",
      });
    }
  }

  function handleExport() {
    const rows = (sites ?? []).map((site) => ({
      Название: site.name,
      Адрес: site.address,
      Филиал: site.branch,
      Заказчик: site.customer,
      Клиент: site.client,
      Менеджер: site.manager,
      Руководитель: site.director,
      Проект: site.project,
      Водитель: site.driver,
      "Площадь, м²": site.storeArea,
    }));
    exportRowsToExcel(rows, TEMPLATE_HEADERS, "объекты.xlsx");
  }

  function openCreateDialog() {
    setForm(EMPTY_FORM);
    setDialogOpen(true);
  }

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();

    const data = {
      name: form.name,
      address: form.address,
      branch: form.branch,
      customer: form.customer,
      client: form.client,
      manager: form.manager,
      director: form.director,
      project: form.project,
      driver: form.driver,
      storeArea: Number(form.storeArea),
    };

    createSite.mutate({ data });
  }

  return (
    <div className="space-y-6">
      <h1
        className="text-2xl font-bold text-blue-900 bg-[#f5ecd9] rounded-md px-4 py-2 block w-full"
        data-testid="text-page-title"
      >
        Объекты
      </h1>
      <div className="flex items-center justify-between">
        <div>
          <p className="text-muted-foreground text-sm mt-1">
            Справочник обслуживаемых объектов
          </p>
        </div>
        <div className="flex items-center gap-2 flex-wrap justify-end">
          {canEditSites && (
            <input
              ref={fileInputRef}
              type="file"
              accept=".xlsx,.xls,.csv"
              className="hidden"
              onChange={handleImportFile}
              data-testid="input-import-sites"
            />
          )}
          <Button
            variant="outline"
            onClick={() =>
              downloadTemplate(TEMPLATE_HEADERS, "шаблон-объекты.xlsx")
            }
            data-testid="button-download-template-sites"
          >
            <FileDown className="h-4 w-4 mr-2" />
            Выгрузить шаблон
          </Button>
          {canEditSites && (
            <Button
              variant="outline"
              onClick={() => fileInputRef.current?.click()}
              disabled={createSitesBulk.isPending}
              data-testid="button-import-sites"
            >
              <Upload className="h-4 w-4 mr-2" />
              Загрузить шаблон
            </Button>
          )}
          <Button
            variant="outline"
            onClick={handleExport}
            data-testid="button-export-sites"
          >
            <Download className="h-4 w-4 mr-2" />
            Выгрузить
          </Button>
          {canEditSites && (
            <Button onClick={openCreateDialog} data-testid="button-add-site">
              <Plus className="h-4 w-4 mr-2" />
              Добавить объект
            </Button>
          )}
        </div>
      </div>

      <div className="flex items-center gap-3 flex-wrap">
        <div className="relative w-64">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Поиск по названию..."
            className="pl-8"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            data-testid="input-search-sites"
          />
        </div>
        <Popover>
          <PopoverTrigger asChild>
            <Button variant="outline" data-testid="button-open-filters">
              <Filter className="h-4 w-4 mr-2" />
              Фильтры
              {activeFilterCount > 0 && (
                <Badge variant="secondary" className="ml-2">
                  {activeFilterCount}
                </Badge>
              )}
            </Button>
          </PopoverTrigger>
          <PopoverContent className="w-72 space-y-3" align="start">
            {FILTER_FIELDS.map(({ key, label }) => (
              <div className="space-y-2" key={key}>
                <Label>{label}</Label>
                <Input
                  placeholder={`Фильтр: ${label}`}
                  value={fieldFilters[key] ?? ""}
                  onChange={(e) =>
                    setFieldFilters({ ...fieldFilters, [key]: e.target.value })
                  }
                  data-testid={`input-filter-${key}`}
                />
              </div>
            ))}
            {hasActiveFilters && (
              <Button
                variant="ghost"
                size="sm"
                className="w-full"
                onClick={() => setFieldFilters({})}
                data-testid="button-reset-filters"
              >
                <X className="h-4 w-4 mr-1" />
                Сбросить фильтры
              </Button>
            )}
          </PopoverContent>
        </Popover>
      </div>

      <div className="border rounded-md overflow-x-auto">
        <Table className="text-xs">
          <TableHeader>
            <TableRow>
              <SortableHeader
                field="name"
                label="Название"
                sortField={sortField}
                sortDir={sortDir}
                onSort={handleSort}
              />
              <SortableHeader
                field="address"
                label="Адрес"
                sortField={sortField}
                sortDir={sortDir}
                onSort={handleSort}
              />
              <SortableHeader
                field="branch"
                label="Филиал"
                sortField={sortField}
                sortDir={sortDir}
                onSort={handleSort}
              />
              <SortableHeader
                field="customer"
                label="Заказчик"
                sortField={sortField}
                sortDir={sortDir}
                onSort={handleSort}
              />
              <SortableHeader
                field="client"
                label="Клиент"
                sortField={sortField}
                sortDir={sortDir}
                onSort={handleSort}
              />
              <SortableHeader
                field="manager"
                label="Менеджер"
                sortField={sortField}
                sortDir={sortDir}
                onSort={handleSort}
              />
              <SortableHeader
                field="director"
                label="Руководитель"
                sortField={sortField}
                sortDir={sortDir}
                onSort={handleSort}
              />
              <SortableHeader
                field="project"
                label="Проект"
                sortField={sortField}
                sortDir={sortDir}
                onSort={handleSort}
              />
              <SortableHeader
                field="driver"
                label="Водитель"
                sortField={sortField}
                sortDir={sortDir}
                onSort={handleSort}
              />
              <SortableHeader
                field="storeArea"
                label="Площадь, м²"
                sortField={sortField}
                sortDir={sortDir}
                onSort={handleSort}
                className="text-right"
                align="right"
              />
              <SortableHeader
                field="createdAt"
                label="Добавлен"
                sortField={sortField}
                sortDir={sortDir}
                onSort={handleSort}
              />
              <TableHead className="w-20"></TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {isLoading ? (
              <TableRow>
                <TableCell
                  colSpan={12}
                  className="text-center text-muted-foreground py-8"
                >
                  Загрузка...
                </TableCell>
              </TableRow>
            ) : filteredSites.length > 0 ? (
              filteredSites.map((site) => (
                <TableRow
                  key={site.id}
                  className="cursor-pointer"
                  onClick={() => setLocation(`/sites/${site.id}`)}
                  data-testid={`row-site-${site.id}`}
                >
                  <TableCell className="font-medium whitespace-nowrap py-1.5">
                    {site.name}
                  </TableCell>
                  <TableCell
                    className="text-muted-foreground truncate max-w-[160px] py-1.5"
                    title={site.address}
                  >
                    {site.address}
                  </TableCell>
                  <TableCell
                    className="truncate max-w-[100px] py-1.5"
                    title={site.branch}
                  >
                    {site.branch}
                  </TableCell>
                  <TableCell
                    className="truncate max-w-[110px] py-1.5"
                    title={site.customer}
                  >
                    {site.customer}
                  </TableCell>
                  <TableCell
                    className="truncate max-w-[110px] py-1.5"
                    title={site.client}
                  >
                    {site.client}
                  </TableCell>
                  <TableCell
                    className="truncate max-w-[90px] py-1.5"
                    title={site.manager}
                  >
                    {site.manager}
                  </TableCell>
                  <TableCell
                    className="truncate max-w-[90px] py-1.5"
                    title={site.director}
                  >
                    {site.director}
                  </TableCell>
                  <TableCell
                    className="truncate max-w-[110px] py-1.5"
                    title={site.project}
                  >
                    {site.project}
                  </TableCell>
                  <TableCell
                    className="truncate max-w-[90px] py-1.5"
                    title={site.driver}
                  >
                    {site.driver}
                  </TableCell>
                  <TableCell className="text-right whitespace-nowrap py-1.5">
                    {site.storeArea}
                  </TableCell>
                  <TableCell className="text-muted-foreground whitespace-nowrap py-1.5">
                    {dateFormatter.format(new Date(site.createdAt))}
                  </TableCell>
                  <TableCell
                    className="py-1.5"
                    onClick={(e) => e.stopPropagation()}
                  >
                    {canEditSites && (
                      <div className="flex items-center justify-end gap-1">
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-7 w-7"
                          onClick={() => setLocation(`/sites/${site.id}`)}
                          data-testid={`button-edit-site-${site.id}`}
                        >
                          <Pencil className="h-3.5 w-3.5" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-7 w-7"
                          onClick={() => setDeleteTarget(site)}
                          data-testid={`button-delete-site-${site.id}`}
                        >
                          <Trash2 className="h-3.5 w-3.5 text-destructive" />
                        </Button>
                      </div>
                    )}
                  </TableCell>
                </TableRow>
              ))
            ) : (
              <TableRow>
                <TableCell
                  colSpan={12}
                  className="text-center text-muted-foreground py-8"
                >
                  Объекты не найдены
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg max-h-[85vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Новый объект</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="name">Название (уникальное)</Label>
              <Input
                id="name"
                required
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
                data-testid="input-site-name"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="address">Адрес</Label>
              <Input
                id="address"
                required
                value={form.address}
                onChange={(e) => setForm({ ...form, address: e.target.value })}
                data-testid="input-site-address"
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="branch">Филиал</Label>
                <Input
                  id="branch"
                  required
                  value={form.branch}
                  onChange={(e) => setForm({ ...form, branch: e.target.value })}
                  data-testid="input-site-branch"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="client">Клиент</Label>
                <Input
                  id="client"
                  required
                  value={form.client}
                  onChange={(e) => setForm({ ...form, client: e.target.value })}
                  data-testid="input-site-client"
                />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="customer">Заказчик</Label>
                <Input
                  id="customer"
                  required
                  value={form.customer}
                  onChange={(e) =>
                    setForm({ ...form, customer: e.target.value })
                  }
                  data-testid="input-site-customer"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="manager">Закреплённый менеджер</Label>
                <Input
                  id="manager"
                  required
                  value={form.manager}
                  onChange={(e) =>
                    setForm({ ...form, manager: e.target.value })
                  }
                  data-testid="input-site-manager"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="director">Закреплённый руководитель</Label>
                <Input
                  id="director"
                  required
                  value={form.director}
                  onChange={(e) =>
                    setForm({ ...form, director: e.target.value })
                  }
                  data-testid="input-site-director"
                />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="project">Закреплённый проект</Label>
                <Input
                  id="project"
                  required
                  value={form.project}
                  onChange={(e) =>
                    setForm({ ...form, project: e.target.value })
                  }
                  data-testid="input-site-project"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="driver">Закреплённый водитель</Label>
                <Input
                  id="driver"
                  required
                  value={form.driver}
                  onChange={(e) => setForm({ ...form, driver: e.target.value })}
                  data-testid="input-site-driver"
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="storeArea">Площадь магазина, м²</Label>
              <Input
                id="storeArea"
                type="number"
                min="0"
                step="0.01"
                required
                value={form.storeArea}
                onChange={(e) =>
                  setForm({ ...form, storeArea: e.target.value })
                }
                data-testid="input-site-store-area"
              />
            </div>
            <DialogFooter>
              <Button
                type="submit"
                disabled={createSite.isPending}
                data-testid="button-submit-site"
              >
                Создать
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      <AlertDialog
        open={!!deleteTarget}
        onOpenChange={(open) => !open && setDeleteTarget(null)}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Удалить объект?</AlertDialogTitle>
            <AlertDialogDescription>
              Объект «{deleteTarget?.name}» будет удалён без возможности
              восстановления.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Отмена</AlertDialogCancel>
            <AlertDialogAction
              onClick={() =>
                deleteTarget && deleteSite.mutate({ id: deleteTarget.id })
              }
              data-testid="button-confirm-delete-site"
            >
              Удалить
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
