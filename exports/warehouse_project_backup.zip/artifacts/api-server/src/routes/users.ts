import { Router, type IRouter } from "express";
import { eq } from "drizzle-orm";
import { clerkClient } from "@clerk/express";
import { db, appUsersTable } from "@workspace/db";
import {
  GetCurrentUserResponse,
  ListUsersResponse,
  UpdateUserRoleParams,
  UpdateUserRoleBody,
  UpdateUserRoleResponse,
  InviteUserBody,
  InviteUserResponse,
} from "@workspace/api-zod";
import { requireAdmin } from "../middlewares/requirePermission";

const router: IRouter = Router();

function toAppUserDto(row: typeof appUsersTable.$inferSelect) {
  return {
    id: row.id,
    clerkUserId: row.clerkUserId,
    email: row.email,
    name: row.name,
    phone: row.phone,
    role: row.role,
    editableSections: row.editableSections,
    createdAt: row.createdAt,
  };
}

router.get("/users/me", async (req, res): Promise<void> => {
  if (!req.appUser) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }
  res.json(GetCurrentUserResponse.parse(toAppUserDto(req.appUser)));
});

router.get("/users", requireAdmin, async (_req, res): Promise<void> => {
  const rows = await db.select().from(appUsersTable).orderBy(appUsersTable.createdAt);
  res.json(ListUsersResponse.parse(rows.map(toAppUserDto)));
});

router.patch("/users/:id", requireAdmin, async (req, res): Promise<void> => {
  const params = UpdateUserRoleParams.safeParse(req.params);
  const body = UpdateUserRoleBody.safeParse(req.body);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  if (!body.success) {
    res.status(400).json({ error: body.error.message });
    return;
  }

  const [updated] = await db
    .update(appUsersTable)
    .set({
      ...(body.data.name !== undefined ? { name: body.data.name } : {}),
      ...(body.data.phone !== undefined ? { phone: body.data.phone } : {}),
      role: body.data.role,
      editableSections: body.data.role === "editor" ? body.data.editableSections : [],
      updatedAt: new Date(),
    })
    .where(eq(appUsersTable.id, params.data.id))
    .returning();

  if (!updated) {
    res.status(404).json({ error: "User not found" });
    return;
  }

  res.json(UpdateUserRoleResponse.parse(toAppUserDto(updated)));
});

router.post("/users/invite", requireAdmin, async (req, res): Promise<void> => {
  const parsed = InviteUserBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  try {
    const invitation = await clerkClient.invitations.createInvitation({
      emailAddress: parsed.data.email,
    });
    res.status(201).json(InviteUserResponse.parse({ email: invitation.emailAddress, status: invitation.status }));
  } catch (err) {
    req.log.error({ err }, "Failed to create Clerk invitation");
    const message = err instanceof Error ? err.message : "Не удалось отправить приглашение";
    res.status(400).json({ error: message });
  }
});

export default router;
