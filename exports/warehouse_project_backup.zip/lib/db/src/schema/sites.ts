import { index, numeric, pgTable, text, timestamp, uuid } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const sitesTable = pgTable(
  "sites",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    name: text("name").notNull().unique(),
    address: text("address").notNull(),
    branch: text("branch").notNull(),
    customer: text("customer").notNull().default(""),
    client: text("client").notNull(),
    manager: text("manager").notNull(),
    director: text("director").notNull(),
    project: text("project").notNull(),
    driver: text("driver").notNull(),
    storeArea: numeric("store_area", { precision: 12, scale: 2 }).notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [
    index("sites_client_idx").on(table.client),
    index("sites_driver_idx").on(table.driver),
  ],
);

export const insertSiteSchema = createInsertSchema(sitesTable).omit({
  id: true,
  createdAt: true,
});
export type InsertSite = z.infer<typeof insertSiteSchema>;
export type Site = typeof sitesTable.$inferSelect;
