import { useEffect, useRef } from "react";
import { Switch, Route, Redirect, useLocation, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider, useQueryClient } from "@tanstack/react-query";
import { ClerkProvider, SignIn, SignUp, Show, useClerk } from "@clerk/react";
import { publishableKeyFromHost } from "@clerk/react/internal";
import { shadcn } from "@clerk/themes";
import { ruRU } from "@clerk/localizations";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Layout } from "@/components/layout";
import NotFound from "@/pages/not-found";
import Dashboard from "@/pages/dashboard";
import Products from "@/pages/products";
import Categories from "@/pages/categories";
import GoodsReceipts from "@/pages/goods-receipts";
import Sites from "@/pages/sites";
import SiteDetail from "@/pages/site-detail";
import GoodsReceiptDetail from "@/pages/goods-receipt-detail";
import GoodsReceiptPrint from "@/pages/goods-receipt-print";
import Deliveries from "@/pages/deliveries";
import DeliveryRun from "@/pages/delivery-run";
import Clients from "@/pages/clients";
import Orders from "@/pages/orders";
import OrderDetail from "@/pages/order-detail";
import Shipments from "@/pages/shipments";
import ShipmentDetail from "@/pages/shipment-detail";
import ShipmentPrint from "@/pages/shipment-print";
import OrderPrint from "@/pages/order-print";
import Users from "@/pages/users";
import { PermissionsProvider } from "@/hooks/use-permissions";

const queryClient = new QueryClient();

// REQUIRED — copy verbatim. Resolves the key from window.location.hostname so the
// same build serves multiple Clerk custom domains. Do not inline the env var, leave
// publishableKey undefined, or replace publishableKeyFromHost with anything else.
const clerkPubKey = publishableKeyFromHost(
  window.location.hostname,
  import.meta.env.VITE_CLERK_PUBLISHABLE_KEY,
);

// REQUIRED — copy verbatim. Empty in dev (Clerk hits dev FAPI directly), auto-set
// in prod. Do NOT gate on import.meta.env.PROD / NODE_ENV — the empty dev value
// is intentional, and any branching breaks the prod proxy.
const clerkProxyUrl = import.meta.env.VITE_CLERK_PROXY_URL;

const basePath = import.meta.env.BASE_URL.replace(/\/$/, "");

// Clerk passes full paths to routerPush/routerReplace, but wouter's
// setLocation prepends the base — strip it to avoid doubling.
function stripBase(path: string): string {
  return basePath && path.startsWith(basePath)
    ? path.slice(basePath.length) || "/"
    : path;
}

if (!clerkPubKey) {
  throw new Error("Missing VITE_CLERK_PUBLISHABLE_KEY in .env file");
}

const clerkAppearance = {
  theme: shadcn,
  cssLayerName: "clerk",
  options: {
    logoPlacement: "inside" as const,
    logoLinkUrl: basePath || "/",
    logoImageUrl: `${window.location.origin}${basePath}/logo.svg`,
  },
  variables: {
    colorPrimary: "hsl(24 100% 50%)",
    colorForeground: "hsl(220 10% 15%)",
    colorMutedForeground: "hsl(220 10% 40%)",
    colorDanger: "hsl(0 84% 60%)",
    colorBackground: "hsl(0 0% 100%)",
    colorInput: "hsl(0 0% 100%)",
    colorInputForeground: "hsl(220 10% 15%)",
    colorNeutral: "hsl(220 10% 85%)",
    fontFamily: "'Inter', sans-serif",
    borderRadius: "0.25rem",
  },
  elements: {
    rootBox: "w-full flex justify-center",
    cardBox: "bg-white rounded-2xl w-[440px] max-w-full overflow-hidden shadow-lg",
    card: "!shadow-none !border-0 !bg-transparent !rounded-none",
    footer: "!shadow-none !border-0 !bg-transparent !rounded-none",
    headerTitle: "text-xl font-bold text-foreground",
    headerSubtitle: "text-muted-foreground",
    socialButtonsBlockButtonText: "text-foreground font-medium",
    formFieldLabel: "text-foreground font-medium",
    footerActionLink: "text-primary font-medium hover:text-primary/80",
    footerActionText: "text-muted-foreground",
    dividerText: "text-muted-foreground",
    identityPreviewEditButton: "text-primary",
    formFieldSuccessText: "text-foreground",
    alertText: "text-foreground",
    logoBox: "flex justify-center py-2",
    logoImage: "h-10 w-10",
    socialButtonsBlockButton: "border-border",
    formButtonPrimary:
      "bg-primary text-primary-foreground hover:bg-primary/90 normal-case",
    formFieldInput: "bg-white border-border text-foreground",
    footerAction: "text-muted-foreground",
    dividerLine: "bg-border",
    alert: "bg-destructive/10 border-destructive/30",
    otpCodeFieldInput: "border-border text-foreground",
    formFieldRow: "",
    main: "gap-4",
  },
};

function SignInPage() {
  return (
    <div className="flex min-h-[100dvh] flex-col items-center justify-center bg-background px-4">
      <SignIn
        routing="path"
        path={`${basePath}/sign-in`}
        signUpUrl={`${basePath}/sign-up`}
      />
    </div>
  );
}

function SignUpPage() {
  return (
    <div className="flex min-h-[100dvh] flex-col items-center justify-center bg-background px-4">
      <SignUp
        routing="path"
        path={`${basePath}/sign-up`}
        signInUrl={`${basePath}/sign-in`}
      />
    </div>
  );
}

function ClerkQueryClientCacheInvalidator() {
  const { addListener } = useClerk();
  const queryClient = useQueryClient();
  const prevUserIdRef = useRef<string | null | undefined>(undefined);

  useEffect(() => {
    const unsubscribe = addListener(({ user }) => {
      const userId = user?.id ?? null;
      if (
        prevUserIdRef.current !== undefined &&
        prevUserIdRef.current !== userId
      ) {
        queryClient.clear();
      }
      prevUserIdRef.current = userId;
    });
    return unsubscribe;
  }, [addListener, queryClient]);

  return null;
}

function AuthenticatedApp() {
  return (
    <PermissionsProvider>
      <Layout>
        <Switch>
          <Route path="/" component={Dashboard} />
          <Route path="/products" component={Products} />
          <Route path="/categories" component={Categories} />
          <Route path="/receipts" component={GoodsReceipts} />
          <Route path="/receipts/:id" component={GoodsReceiptDetail} />
          <Route path="/sites" component={Sites} />
          <Route path="/sites/:id" component={SiteDetail} />
          <Route path="/deliveries" component={Deliveries} />
          <Route path="/deliveries/run" component={DeliveryRun} />
          <Route path="/clients" component={Clients} />
          <Route path="/orders" component={Orders} />
          <Route path="/orders/:id" component={OrderDetail} />
          <Route path="/shipments" component={Shipments} />
          <Route path="/shipments/:id" component={ShipmentDetail} />
          <Route path="/users" component={Users} />
          <Route component={NotFound} />
        </Switch>
      </Layout>
    </PermissionsProvider>
  );
}

// TEMPORARY: lets us build/test the app without going through Clerk sign-in.
// Only takes effect when VITE_DISABLE_AUTH=true, which is only set in the
// development environment. Remove this (and the VITE_DISABLE_AUTH env var)
// before relying on real auth again — e.g. before testing login in production.
const isAuthDisabled = import.meta.env.VITE_DISABLE_AUTH === "true";

function MainRouter() {
  if (isAuthDisabled) {
    return <AuthenticatedApp />;
  }

  return (
    <>
      <Show when="signed-in">
        <AuthenticatedApp />
      </Show>
      <Show when="signed-out">
        <Redirect to="/sign-in" />
      </Show>
    </>
  );
}

function ProtectedPrintRoute({
  component: Component,
}: {
  component: React.ComponentType;
}) {
  if (isAuthDisabled) {
    return <Component />;
  }

  return (
    <>
      <Show when="signed-in">
        <Component />
      </Show>
      <Show when="signed-out">
        <Redirect to="/sign-in" />
      </Show>
    </>
  );
}

function ClerkProviderWithRoutes() {
  const [, setLocation] = useLocation();

  return (
    <ClerkProvider
      publishableKey={clerkPubKey}
      proxyUrl={clerkProxyUrl}
      appearance={clerkAppearance}
      signInUrl={`${basePath}/sign-in`}
      signUpUrl={`${basePath}/sign-up`}
      localization={{
        ...ruRU,
        signIn: {
          ...ruRU.signIn,
          start: {
            ...ruRU.signIn?.start,
            title: 'ООО ТД "Альянс"',
            subtitle: "Войдите, чтобы продолжить работу",
          },
        },
        signUp: {
          ...ruRU.signUp,
          start: {
            ...ruRU.signUp?.start,
            title: 'ООО ТД "Альянс"',
            subtitle: "Создайте аккаунт сотрудника",
          },
        },
      }}
      routerPush={(to) => setLocation(stripBase(to))}
      routerReplace={(to) => setLocation(stripBase(to), { replace: true })}
    >
      <QueryClientProvider client={queryClient}>
        <ClerkQueryClientCacheInvalidator />
        <Switch>
          <Route path="/shipments/:id/print">
            <ProtectedPrintRoute component={ShipmentPrint} />
          </Route>
          <Route path="/orders/:id/print">
            <ProtectedPrintRoute component={OrderPrint} />
          </Route>
          <Route path="/receipts/:id/print">
            <ProtectedPrintRoute component={GoodsReceiptPrint} />
          </Route>
          <Route path="/sign-in/*?" component={SignInPage} />
          <Route path="/sign-up/*?" component={SignUpPage} />
          <Route>
            <MainRouter />
          </Route>
        </Switch>
      </QueryClientProvider>
    </ClerkProvider>
  );
}

function App() {
  return (
    <TooltipProvider>
      <WouterRouter base={basePath}>
        <ClerkProviderWithRoutes />
      </WouterRouter>
      <Toaster />
    </TooltipProvider>
  );
}

export default App;
