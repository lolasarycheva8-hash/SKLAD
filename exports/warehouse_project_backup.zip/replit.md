# Складской учёт

Русскоязычное веб-приложение для складского учёта: товары, категории, приход/расход, остатки на складе, заказы клиентов, отгрузки и печатные накладные.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 5000)
- `pnpm --filter @workspace/warehouse run dev` — run the warehouse frontend
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)
- Frontend: React + Vite, wouter routing, TanStack Query, shadcn/ui, Tailwind

## Where things live

- `lib/api-spec/openapi.yaml` — source of truth for the API contract (categories, products, movements, dashboard summary, clients, orders, shipments)
- `lib/db/src/schema/` — Drizzle schema: `categories.ts`, `products.ts`, `movements.ts`, `clients.ts`, `orders.ts`, `order-items.ts`, `shipments.ts`, `shipment-items.ts`
- `artifacts/api-server/src/routes/` — Express route handlers (categories, products, movements, dashboard, clients, orders, shipments)
- `artifacts/api-server/src/lib/stock.ts` — current-stock aggregation from movements (in - out)
- `artifacts/api-server/src/lib/orders.ts` — order DTO assembly + `getShippedQuantityMap` (aggregates shipment_items by productId across all shipments of an order)
- `artifacts/api-server/src/lib/shipments.ts` — shipment DTO assembly (resolves client/site/product names, uses order-item price not current product price)
- `artifacts/warehouse/src/pages/` — frontend pages: dashboard, products, movements, sites, deliveries, clients, orders, order-detail, order-print, shipments, shipment-print (no standalone categories page — see Architecture decisions)
- `artifacts/warehouse/src/components/layout.tsx` — sidebar navigation shell

## Architecture decisions

- No `stock` column on products; current stock is computed on the fly by aggregating `movements` (sum of `in` minus `out`) per product. Keeps stock always consistent with the movement ledger.
- Authentication via Replit-managed Clerk (email/password + Google SSO by default): the entire app is gated behind sign-in — the whole warehouse UI (not just a landing page) requires an authenticated session, since this is an internal staff tool with no public content. `requireAuth` middleware (`artifacts/api-server/src/middlewares/requireAuth.ts`) protects every `/api` route except `/api/healthz`. If the team wants email/password only (no Google), disable Google in the Auth pane in the workspace toolbar.
- Role-based access control (RBAC): three roles — `admin` (full rights, including managing other users' roles/permissions at `/users`), `editor` (edit rights limited to a per-user configurable set of sections), `viewer` (read-only everywhere). Sections: products, movements, sites, deliveries, clients, orders, shipments (categories bundled under "products" since there's no standalone categories page). The first-ever authenticated user is auto-promoted to admin on JIT provisioning (`requireAuth.ts`); everyone after that defaults to viewer and must be promoted via the Users page. Server enforces permissions via `requirePermission(section)` middleware on every write route (`artifacts/api-server/src/middlewares/requirePermission.ts`); the frontend additionally hides/disables edit affordances (create/edit/delete buttons, inputs) per section via `usePermissions().canEdit(section)` (`artifacts/warehouse/src/hooks/use-permissions.tsx`) — this is UX-only, the server check is the actual authorization boundary.
- DB indexes added on `sites` (client, driver), `shipments` (orderId, siteId, shipmentDate, createdAt), `movements` (productId, type, createdAt), `orders` (clientId, isPaid, createdAt) to keep queries fast at scale (5000+ sites, 7000+ shipments/month).
- Movement types are `in` / `out` (Postgres enum), mapped to "Приход" / "Расход" in the Russian UI.
- Low stock definition: `currentStock < minStock * 0.3` (strictly less than 30% of minimum stock), used consistently in both the products list and dashboard summary.
- Excel import (`xlsx` package, client-side parsing) is supported for справочники: товары, объекты, график доставок plan. Each uses a `POST .../bulk` endpoint with upsert semantics (products by `sku`, sites by `name`); import UI lives on each respective page (`products.tsx`, `sites.tsx`, `deliveries.tsx`) via `src/lib/excel-import.ts` helpers (template download/upload with strict header validation, plus Excel export of current rows).
- Категории page removed entirely; category management (create/delete) is done inline in the product create/edit dialog via a popover next to the category select. Categories API/schema still exist server-side, just no standalone frontend route/nav item.
- Per-field filters on справочники (Товары, Объекты, График доставок, Движения) are all client-side (filter already-fetched lists), not server query params.
- Dashboard has a "Сегодня план" card at the top showing today's total planned deliveries + per-driver breakdown with progress «выполнено N из M» (`todayTotal`/`todayByDriver` with `count`+`done` on `DeliveryDashboardSummary`, computed server-side by matching today's date; `done` = deliveries with `actualDate` set). Driver rows are expandable and list today's deliveries (`todayDeliveries` on the summary DTO); pending ones show a «Выполнено» button that PATCHes the delivery with `actualDate = today` — visible only with edit rights on deliveries.
- Client orders + shipments: an order (`orders`/`order_items`) belongs to one client and lists product/quantity/price lines; it has no site — a site is chosen per shipment, so one order can be fulfilled across multiple sites in batches, or entirely to one site, without modeling that choice at order creation.
- Standalone «Отгрузки» section (`/shipments`) lists all shipments across all orders/clients and lets you create one directly (choose a paid order → its remaining items load automatically → choose a site → choose/confirm driver). Order detail also has an inline "Новая отгрузка" action for convenience, sharing the same creation endpoint. Both flows default the driver field to the selected site's assigned `driver`, editable by the user before saving.
- Shipment DTO includes `orderNumber` (short form of the order id) so the shipments list and printable накладная can display which order a shipment belongs to without a client join for that purpose.
- Core business rule enforced server-side (not just UI): a shipment can only be created against a **paid** order (`orders.isPaid`), and per-product shipped quantity (summed across all shipments of that order) can never exceed the ordered quantity. Both checks live in `POST /shipments`; violations return 400 with a Russian error message.
- Creating a shipment is transactional: inserts the shipment + `shipment_items`, then inserts one `movements` row per item with `type: "out"` (reason references the order id + site name) — this is the only way stock is deducted for client shipments, keeping the movement ledger the single source of truth for stock (see stock architecture decision above).
- Shipment line pricing is taken from the parent order's `order_items.price` at the time of order creation, not the product's current sale price — so historical накладные stay accurate even if product prices change later.
- Printable накладная (`/shipments/:id/print`) is a standalone route rendered outside the sidebar `Layout` (added as a top-level `Switch` branch in `App.tsx` before the layout route) so it can be printed cleanly via `window.print()`.
- Printable order (`/orders/:id/print`) follows the same standalone-route pattern as the shipment invoice, showing client, items with ordered/shipped quantities, totals, and signature fields — accessible from the orders list and order detail page.
- Deleting a client is blocked if they have any orders; deleting an order is blocked if it has any shipments — both enforced with a 409 check in the route before the delete, not a DB constraint failure.
- Shipments support `PATCH /shipments/:id` for editing metadata only (siteId, driver, shipmentDate, note) — items/quantities stay immutable after creation since they're tied to the movement ledger; there is a dedicated `/shipments/:id` detail page with an edit toggle for this.
- "Copy" affordances for orders and shipments duplicate the source's client/items/site/driver/note into the create form (or, for order copy, directly create a new unpaid order via the API) rather than mutating the original — available from both list rows and detail pages. Shipment copy is triggered via a `?copyFrom=<id>` query param on `/shipments` that the page watches to auto-open the pre-filled create dialog; order-to-shipment jump uses `?orderId=<id>` the same way.
- "Поступление товара" (goods receipt) is a dialog on the Движения page (`POST /products/receipt`), not a separate document table — it's implemented as a product create/update + `in` movement combo. If a receipt against an existing product changes its sale price, a brand-new product card is created (same name, auto-generated sku like `sku-2`) rather than overwriting the price, so old stock keeps its old price; if the price is unchanged, the existing card's other fields are updated and stock is added via a movement.
- There is no standalone "Добавить товар" (create product) button/dialog on the Товары page — new products can only enter the catalog via "Поступление товара" on Движения (which both updates stock for existing SKUs and creates new product cards). The Товары page dialog is edit-only.
- Order items can no longer be edited once `isPaid` is true — enforced both server-side (`PATCH /orders/:id` rejects any `items` payload if the order's current `isPaid` is true) and in the UI (order-detail.tsx hides "Редактировать позиции" for paid orders).

## Product

- Dashboard (финальная компоновка, одобрена пользователем 09.07.2026): верхний ряд — три компактные кликабельные карточки одинаковой высоты («Сегодня план» → /deliveries?period=day, «Просрочено — не доставлено» → /deliveries?status=overdue, «Мало на складе» → /products?lowStock=1) без разбивки по водителям; ниже на всю ширину карточка «Заказы за текущий месяц» (3 строки: выставлено/оплачено/ожидается оплата, разделённые линиями, иконка+название слева, сумма справа); под ней на всю ширину «Заказы, ожидающие оплаты» (заголовок и ссылка «Все заказы» внутри CardHeader); дальше блок план-факт по доставкам. No totals/value/recent-movements cards.
- Products: list/search/filter (by low-stock), create/edit/delete, category assignment, initial stock on creation, поставщик/контакт поставщика fields, Excel bulk import.
- Movements: log приход/расход per product with reason/note, filterable by type.
- Categories: create/delete, used to group products.
- Sites (Объекты) and Delivery schedule (График доставок) also support Excel bulk import.
- Client orders (Заказы клиентов): create order for a client with multiple product/qty/price lines, mark paid/unpaid, delete (if no shipments yet). Order detail page shows per-item ordered/shipped/remaining quantities and lets you create a shipment (site + driver + date + per-item quantity, capped at remaining) once the order is paid.
- Shipments (Отгрузки): standalone section listing all shipments (order №, client, site, driver, date, sum) and a creation flow that starts from picking a paid order, auto-loads its remaining items, and lets you pick a site + confirm/edit the driver (defaults to the site's assigned driver). Each shipment has a printable накладная with client, order number, site/address, driver, date, item lines, totals, and signature/stamp fields.

## User preferences

- Кнопки «Добавить» должны быть всегда активны (не блокироваться пустыми полями); ввод и валидация — внутри открывающегося диалога (как сделано в Категориях).

## Gotchas

- Products have no direct stock field — always compute via `getCurrentStockMap`/`getCurrentStockForProduct` in `artifacts/api-server/src/lib/stock.ts` rather than querying a stock column.

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
