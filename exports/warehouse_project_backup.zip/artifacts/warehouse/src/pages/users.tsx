import { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import {
  useListUsers,
  useUpdateUserRole,
  useInviteUser,
  getListUsersQueryKey,
  getGetCurrentUserQueryKey,
} from "@workspace/api-client-react";
import type { AppUser, UserRole, Section } from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Pencil, Check, X, UserPlus } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { usePermissions } from "@/hooks/use-permissions";

const ROLE_LABELS: Record<UserRole, string> = {
  admin: "Администратор",
  editor: "Редактор",
  viewer: "Просмотр",
};

const SECTION_LABELS: Record<Section, string> = {
  products: "Товары",
  receipts: "Поступление товара",
  sites: "Объекты",
  deliveries: "График доставок",
  clients: "Клиенты",
  orders: "Заказы",
  shipments: "Отгрузки",
};

const SECTIONS: Section[] = [
  "products",
  "receipts",
  "sites",
  "deliveries",
  "clients",
  "orders",
  "shipments",
];

function UserRow({
  user,
  currentUserId,
}: {
  user: AppUser;
  currentUserId: string | undefined;
}) {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const [role, setRole] = useState<UserRole>(user.role);
  const [editableSections, setEditableSections] = useState<Section[]>(
    user.editableSections,
  );
  const [editingInfo, setEditingInfo] = useState(false);
  const [nameInput, setNameInput] = useState(user.name ?? "");
  const [phoneInput, setPhoneInput] = useState(user.phone ?? "");

  const isSelf = user.id === currentUserId;

  const updateUserRole = useUpdateUserRole({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListUsersQueryKey() });
        queryClient.invalidateQueries({
          queryKey: getGetCurrentUserQueryKey(),
        });
        toast({ title: "Права обновлены" });
      },
      onError: (error) => {
        toast({
          title: "Ошибка",
          description: error.message,
          variant: "destructive",
        });
      },
    },
  });

  function save(nextRole: UserRole, nextSections: Section[]) {
    updateUserRole.mutate({
      id: user.id,
      data: {
        role: nextRole,
        editableSections: nextRole === "editor" ? nextSections : [],
      },
    });
  }

  function handleRoleChange(value: string) {
    const nextRole = value as UserRole;
    setRole(nextRole);
    save(nextRole, editableSections);
  }

  function toggleSection(section: Section, checked: boolean) {
    const next = checked
      ? [...editableSections, section]
      : editableSections.filter((s) => s !== section);
    setEditableSections(next);
    save(role, next);
  }

  function saveInfo() {
    updateUserRole.mutate(
      {
        id: user.id,
        data: {
          name: nameInput.trim() || null,
          phone: phoneInput.trim() || null,
          role,
          editableSections: role === "editor" ? editableSections : [],
        },
      },
      { onSuccess: () => setEditingInfo(false) },
    );
  }

  function cancelInfo() {
    setNameInput(user.name ?? "");
    setPhoneInput(user.phone ?? "");
    setEditingInfo(false);
  }

  return (
    <TableRow data-testid={`row-user-${user.id}`}>
      <TableCell className="py-2">
        <div className="font-medium">{user.email}</div>
      </TableCell>
      <TableCell className="py-2">
        {editingInfo ? (
          <Input
            placeholder="ФИО"
            value={nameInput}
            onChange={(e) => setNameInput(e.target.value)}
            className="h-7 text-xs w-40"
            data-testid={`input-name-${user.id}`}
          />
        ) : (
          <span data-testid={`text-name-${user.id}`}>{user.name || "—"}</span>
        )}
      </TableCell>
      <TableCell className="py-2">
        {editingInfo ? (
          <div className="flex items-center gap-1.5">
            <Input
              placeholder="Телефон"
              value={phoneInput}
              onChange={(e) => setPhoneInput(e.target.value)}
              className="h-7 text-xs w-36"
              data-testid={`input-phone-${user.id}`}
            />
            <button
              type="button"
              onClick={saveInfo}
              className="text-green-600 hover:text-green-700"
              data-testid={`button-save-info-${user.id}`}
            >
              <Check className="h-4 w-4" />
            </button>
            <button
              type="button"
              onClick={cancelInfo}
              className="text-muted-foreground hover:text-foreground"
              data-testid={`button-cancel-info-${user.id}`}
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        ) : (
          <div className="group flex items-center gap-1.5">
            <span data-testid={`text-phone-${user.id}`}>
              {user.phone || "—"}
            </span>
            <button
              type="button"
              onClick={() => setEditingInfo(true)}
              className="text-muted-foreground hover:text-foreground opacity-0 group-hover:opacity-100"
              data-testid={`button-edit-info-${user.id}`}
            >
              <Pencil className="h-3.5 w-3.5" />
            </button>
          </div>
        )}
      </TableCell>
      <TableCell className="py-2">
        <Select value={role} onValueChange={handleRoleChange} disabled={isSelf}>
          <SelectTrigger
            className="w-40"
            data-testid={`select-role-${user.id}`}
          >
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {(Object.keys(ROLE_LABELS) as UserRole[]).map((r) => (
              <SelectItem key={r} value={r}>
                {ROLE_LABELS[r]}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        {isSelf && (
          <div className="text-xs text-muted-foreground mt-1">
            Нельзя менять себе
          </div>
        )}
      </TableCell>
      <TableCell className="py-2">
        {role === "editor" ? (
          <div className="flex flex-wrap gap-x-4 gap-y-1.5 max-w-md">
            {SECTIONS.map((section) => (
              <label
                key={section}
                className="flex items-center gap-1.5 text-sm"
              >
                <Checkbox
                  checked={editableSections.includes(section)}
                  disabled={isSelf}
                  onCheckedChange={(checked) =>
                    toggleSection(section, checked === true)
                  }
                  data-testid={`checkbox-section-${user.id}-${section}`}
                />
                {SECTION_LABELS[section]}
              </label>
            ))}
          </div>
        ) : (
          <span className="text-muted-foreground text-sm">
            {role === "admin" ? "Полный доступ" : "Только просмотр"}
          </span>
        )}
      </TableCell>
    </TableRow>
  );
}

export default function Users() {
  const { data: users, isLoading } = useListUsers();
  const { user: currentUser } = usePermissions();
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const [inviteDialogOpen, setInviteDialogOpen] = useState(false);
  const [inviteEmail, setInviteEmail] = useState("");

  const inviteUser = useInviteUser({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListUsersQueryKey() });
        setInviteDialogOpen(false);
        setInviteEmail("");
        toast({ title: "Приглашение отправлено" });
      },
      onError: (error: any) => {
        toast({
          title: "Ошибка",
          description: error?.response?.data?.error ?? error.message,
          variant: "destructive",
        });
      },
    },
  });

  function handleInvite(e: React.FormEvent) {
    e.preventDefault();
    if (!inviteEmail.trim()) return;
    inviteUser.mutate({ data: { email: inviteEmail.trim() } });
  }

  return (
    <div className="space-y-6">
      <h1
        className="text-2xl font-bold text-blue-900 bg-[#f5ecd9] rounded-md px-4 py-2 block w-full"
        data-testid="text-page-title"
      >
        Пользователи
      </h1>
      <div className="flex items-center justify-between">
        <div>
          <p className="text-muted-foreground text-sm mt-1">
            Управление ролями и правами редактирования сотрудников
          </p>
        </div>
        <Button
          onClick={() => setInviteDialogOpen(true)}
          data-testid="button-invite-user"
        >
          <UserPlus className="h-4 w-4 mr-2" />
          Пригласить пользователя
        </Button>
      </div>

      <div className="border rounded-md overflow-x-auto">
        <Table className="text-xs">
          <TableHeader>
            <TableRow>
              <TableHead>Email</TableHead>
              <TableHead>ФИО</TableHead>
              <TableHead>Телефон</TableHead>
              <TableHead>Роль</TableHead>
              <TableHead>Разделы для редактирования</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {isLoading ? (
              <TableRow>
                <TableCell
                  colSpan={5}
                  className="text-center text-muted-foreground py-8"
                >
                  Загрузка...
                </TableCell>
              </TableRow>
            ) : (users ?? []).length > 0 ? (
              (users ?? []).map((user) => (
                <UserRow
                  key={user.id}
                  user={user}
                  currentUserId={currentUser?.id}
                />
              ))
            ) : (
              <TableRow>
                <TableCell
                  colSpan={5}
                  className="text-center text-muted-foreground py-8"
                >
                  Пользователи не найдены
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>

      <Dialog open={inviteDialogOpen} onOpenChange={setInviteDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Пригласить пользователя</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleInvite} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="inviteEmail">Email</Label>
              <Input
                id="inviteEmail"
                type="email"
                required
                value={inviteEmail}
                onChange={(e) => setInviteEmail(e.target.value)}
                placeholder="user@example.com"
                data-testid="input-invite-email"
              />
            </div>
            <DialogFooter>
              <Button
                type="submit"
                disabled={inviteUser.isPending}
                data-testid="button-send-invite"
              >
                Отправить приглашение
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
