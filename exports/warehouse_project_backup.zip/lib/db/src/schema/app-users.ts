import { index, pgEnum, pgTable, text, timestamp, uuid } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const userRoleEnum = pgEnum("user_role", ["admin", "editor", "viewer"]);

export const SECTIONS = [
  "products",
  "receipts",
  "sites",
  "deliveries",
  "clients",
  "orders",
  "shipments",
] as const;
export type Section = (typeof SECTIONS)[number];

export const appUsersTable = pgTable(
  "app_users",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    clerkUserId: text("clerk_user_id").notNull().unique(),
    email: text("email").notNull(),
    name: text("name"),
    phone: text("phone"),
    role: userRoleEnum("role").notNull().default("viewer"),
    editableSections: text("editable_sections")
      .array()
      .notNull()
      .default([]),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [index("app_users_clerk_user_id_idx").on(table.clerkUserId)],
);

export const insertAppUserSchema = createInsertSchema(appUsersTable).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export type InsertAppUser = z.infer<typeof insertAppUserSchema>;
export type AppUser = typeof appUsersTable.$inferSelect;
