import { createContext, useContext } from "react";
import { useGetCurrentUser } from "@workspace/api-client-react";
import type { AppUser, Section } from "@workspace/api-client-react";

type PermissionsContextValue = {
  user: AppUser | undefined;
  isLoading: boolean;
  isAdmin: boolean;
  canEdit: (section: Section) => boolean;
};

const PermissionsContext = createContext<PermissionsContextValue | null>(null);

export function PermissionsProvider({ children }: { children: React.ReactNode }) {
  const { data: user, isLoading } = useGetCurrentUser();

  const isAdmin = user?.role === "admin";

  function canEdit(section: Section): boolean {
    if (!user) return false;
    if (user.role === "admin") return true;
    if (user.role === "editor") return user.editableSections.includes(section);
    return false;
  }

  return (
    <PermissionsContext.Provider value={{ user, isLoading, isAdmin, canEdit }}>
      {children}
    </PermissionsContext.Provider>
  );
}

export function usePermissions(): PermissionsContextValue {
  const ctx = useContext(PermissionsContext);
  if (!ctx) {
    throw new Error("usePermissions must be used within a PermissionsProvider");
  }
  return ctx;
}
