import { Router, type IRouter } from "express";
import healthRouter from "./health";
import categoriesRouter from "./categories";
import productsRouter from "./products";
import goodsReceiptsRouter from "./goods-receipts";
import dashboardRouter from "./dashboard";
import sitesRouter from "./sites";
import deliveriesRouter from "./deliveries";
import clientsRouter from "./clients";
import ordersRouter from "./orders";
import shipmentsRouter from "./shipments";
import usersRouter from "./users";
import { requireAuth } from "../middlewares/requireAuth";

const router: IRouter = Router();

// Health check stays unauthenticated so uptime/monitoring probes can reach it.
router.use(healthRouter);

router.use(requireAuth);

router.use(usersRouter);
router.use(categoriesRouter);
router.use(productsRouter);
router.use(goodsReceiptsRouter);
router.use(dashboardRouter);
router.use(sitesRouter);
router.use(deliveriesRouter);
router.use(clientsRouter);
router.use(ordersRouter);
router.use(shipmentsRouter);

export default router;
