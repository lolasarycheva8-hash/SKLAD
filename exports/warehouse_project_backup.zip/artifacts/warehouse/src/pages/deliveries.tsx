import { useMemo, useRef, useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import {
  useListDeliveries,
  useCreateDeliveriesBulk,
  useUpdateDelivery,
  useDeleteDelivery,
  useListSites,
  getListDeliveriesQueryKey,
  getGetDeliveryDashboardSummaryQueryKey,
} from "@workspace/api-client-react";
import type { Delivery } from "@workspace/api-client-react";
import {
  parseExcelFile,
  readSheetHeaders,
  validateTemplateHeaders,
  downloadTemplate,
  exportRowsToExcel,
  str,
  excelSerialToIsoDate,
} from "@/lib/excel-import";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  SortableHeader,
  type SortDirection,
} from "@/components/sortable-header";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import type { DateRange } from "react-day-picker";
import {
  Plus,
  Trash2,
  Truck,
  CalendarClock,
  CalendarRange,
  ClipboardCheck,
  Upload,
  Download,
  FileDown,
  X,
  Search,
} from "lucide-react";
import { useLocation } from "wouter";
import { useToast } from "@/hooks/use-toast";
import { usePermissions } from "@/hooks/use-permissions";
import {
  format,
  startOfDay,
  endOfDay,
  startOfWeek,
  endOfWeek,
  startOfMonth,
  endOfMonth,
} from "date-fns";
import { ru } from "date-fns/locale";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

const dateFormat = new Intl.DateTimeFormat("ru-RU", {
  day: "2-digit",
  month: "2-digit",
  year: "numeric",
});

function toDateInputValue(iso: string) {
  return iso.slice(0, 10);
}

function currentMonthValue() {
  return new Date().toISOString().slice(0, 7);
}

const STATUS_LABEL: Record<string, string> = {
  pending: "Ожидается",
  on_time: "В срок",
  late: "С опозданием",
  overdue: "Просрочено",
};

const STATUS_VARIANT: Record<
  string,
  "default" | "secondary" | "destructive" | "outline"
> = {
  pending: "outline",
  on_time: "default",
  late: "secondary",
  overdue: "destructive",
};

type ScheduleRow = {
  siteId: string;
  siteName: string;
  driver: string;
  plannedDate: string;
};

const TEMPLATE_HEADERS = ["Объект", "Водитель", "Плановая дата"];

type SortField =
  | "siteName"
  | "driver"
  | "plannedDate"
  | "actualDate"
  | "lagDays"
  | "status";

type PeriodPreset = "day" | "week" | "month" | "custom";

const PERIOD_PRESET_LABEL: Record<PeriodPreset, string> = {
  day: "День",
  week: "Неделя",
  month: "Месяц",
  custom: "Несколько дней",
};

export default function Deliveries() {
  const [, setLocation] = useLocation();
  const [initialParams] = useState(
    () => new URLSearchParams(window.location.search),
  );
  const rawStatus = initialParams.get("status");
  const initialStatus =
    rawStatus && rawStatus in STATUS_LABEL ? rawStatus : null;
  const initialPeriodDay = initialParams.get("period") === "day";
  const [month] = useState(currentMonthValue());
  const [periodPreset, setPeriodPreset] = useState<PeriodPreset>(
    initialPeriodDay ? "day" : "month",
  );
  const [dateRange, setDateRange] = useState<DateRange>(
    initialPeriodDay
      ? { from: startOfDay(new Date()), to: endOfDay(new Date()) }
      : { from: startOfMonth(new Date()), to: endOfMonth(new Date()) },
  );
  const [draftRange, setDraftRange] = useState<DateRange | undefined>(
    dateRange,
  );
  const [periodPopoverOpen, setPeriodPopoverOpen] = useState(false);
  const [generateOpen, setGenerateOpen] = useState(false);
  const [scheduleRows, setScheduleRows] = useState<ScheduleRow[]>([]);
  const [deleteTarget, setDeleteTarget] = useState<Delivery | null>(null);
  const [search, setSearch] = useState("");
  const [filterField, setFilterField] = useState<"site" | "driver" | "status">(
    initialStatus ? "status" : "site",
  );
  const [filterValue, setFilterValue] = useState(initialStatus ?? "");
  const [sortField, setSortField] = useState<SortField>("plannedDate");
  const [sortDir, setSortDir] = useState<SortDirection>("asc");

  const queryClient = useQueryClient();
  const { toast } = useToast();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { canEdit } = usePermissions();
  const canEditDeliveries = canEdit("deliveries");

  function applyPreset(preset: PeriodPreset) {
    const now = new Date();
    let range: DateRange;
    if (preset === "day") {
      range = { from: startOfDay(now), to: endOfDay(now) };
    } else if (preset === "week") {
      range = {
        from: startOfWeek(now, { weekStartsOn: 1 }),
        to: endOfWeek(now, { weekStartsOn: 1 }),
      };
    } else {
      range = { from: startOfMonth(now), to: endOfMonth(now) };
    }
    setPeriodPreset(preset);
    setDateRange(range);
    setDraftRange(range);
    setPeriodPopoverOpen(false);
  }

  function applyCustomRange() {
    if (!draftRange?.from) return;
    const range: DateRange = {
      from: draftRange.from,
      to: draftRange.to ?? draftRange.from,
    };
    setPeriodPreset("custom");
    setDateRange(range);
    setPeriodPopoverOpen(false);
  }

  const periodLabel = dateRange.from
    ? dateRange.to && dateRange.to.getTime() !== dateRange.from.getTime()
      ? `${format(dateRange.from, "dd.MM.yyyy")} – ${format(dateRange.to, "dd.MM.yyyy")}`
      : format(dateRange.from, "dd.MM.yyyy")
    : PERIOD_PRESET_LABEL[periodPreset];

  const dateFrom = dateRange.from
    ? format(dateRange.from, "yyyy-MM-dd")
    : undefined;
  const dateTo = dateRange.to ? format(dateRange.to, "yyyy-MM-dd") : dateFrom;

  const { data: deliveries, isLoading } = useListDeliveries(
    dateFrom ? { dateFrom, dateTo } : { month },
  );
  const { data: sites } = useListSites();

  const invalidate = () => {
    queryClient.invalidateQueries({ queryKey: getListDeliveriesQueryKey() });
    queryClient.invalidateQueries({
      queryKey: getGetDeliveryDashboardSummaryQueryKey(),
    });
  };

  const createBulk = useCreateDeliveriesBulk({
    mutation: {
      onSuccess: () => {
        invalidate();
        setGenerateOpen(false);
        toast({ title: "График сформирован" });
      },
      onError: (error) => {
        toast({
          title: "Ошибка",
          description: error.message,
          variant: "destructive",
        });
      },
    },
  });

  const updateDelivery = useUpdateDelivery({
    mutation: {
      onSuccess: () => {
        invalidate();
        toast({ title: "Факт доставки обновлён" });
      },
      onError: (error) => {
        toast({
          title: "Ошибка",
          description: error.message,
          variant: "destructive",
        });
      },
    },
  });

  const deleteDelivery = useDeleteDelivery({
    mutation: {
      onSuccess: () => {
        invalidate();
        setDeleteTarget(null);
        toast({ title: "Запись удалена" });
      },
      onError: (error) => {
        toast({
          title: "Ошибка",
          description: error.message,
          variant: "destructive",
        });
      },
    },
  });

  async function handleImportFile(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    e.target.value = "";
    if (!file) return;

    try {
      const headers = await readSheetHeaders(file);
      const missing = validateTemplateHeaders(headers, TEMPLATE_HEADERS);
      if (missing.length > 0) {
        toast({
          title: "Файл не соответствует шаблону",
          description: `Отсутствуют колонки: ${missing.join(", ")}`,
          variant: "destructive",
        });
        return;
      }

      const rows = await parseExcelFile(file);
      const siteByName = new Map(
        (sites ?? []).map((site) => [site.name.trim().toLowerCase(), site]),
      );

      const items: { siteId: string; driver: string; plannedDate: string }[] =
        [];
      const missingSites: string[] = [];

      for (const row of rows) {
        const siteName = str(row["Объект"]);
        const site = siteByName.get(siteName.toLowerCase());
        if (!site) {
          if (siteName) missingSites.push(siteName);
          continue;
        }
        items.push({
          siteId: site.id,
          driver: str(row["Водитель"]) || site.driver,
          plannedDate: excelSerialToIsoDate(row["Плановая дата"]),
        });
      }

      if (items.length === 0) {
        toast({
          title: "Файл пуст или объекты не найдены",
          variant: "destructive",
        });
        return;
      }

      if (missingSites.length > 0) {
        toast({
          title: "Некоторые объекты не найдены",
          description: missingSites.join(", "),
          variant: "destructive",
        });
      }

      createBulk.mutate({ data: { items } });
    } catch (error) {
      toast({
        title: "Не удалось прочитать файл",
        description: error instanceof Error ? error.message : String(error),
        variant: "destructive",
      });
    }
  }

  const sortedDeliveries = useMemo(() => {
    const dir = sortDir === "asc" ? 1 : -1;
    return [...(deliveries ?? [])].sort((a, b) => {
      switch (sortField) {
        case "siteName":
          return a.siteName.localeCompare(b.siteName, "ru") * dir;
        case "driver":
          return a.driver.localeCompare(b.driver, "ru") * dir;
        case "plannedDate":
          return a.plannedDate.localeCompare(b.plannedDate) * dir;
        case "actualDate":
          return (a.actualDate ?? "").localeCompare(b.actualDate ?? "") * dir;
        case "lagDays":
          return ((a.lagDays ?? 0) - (b.lagDays ?? 0)) * dir;
        case "status":
          return a.status.localeCompare(b.status) * dir;
        default:
          return 0;
      }
    });
  }, [deliveries, sortField, sortDir]);

  function handleSort(field: SortField) {
    if (field === sortField) {
      setSortDir((d) => (d === "asc" ? "desc" : "asc"));
    } else {
      setSortField(field);
      setSortDir("asc");
    }
  }

  const filteredDeliveries = useMemo(() => {
    const query = search.trim().toLowerCase();
    return sortedDeliveries.filter((delivery) => {
      if (filterValue) {
        if (filterField === "site" && delivery.siteId !== filterValue)
          return false;
        if (
          filterField === "driver" &&
          !delivery.driver.toLowerCase().includes(filterValue.toLowerCase())
        )
          return false;
        if (filterField === "status" && delivery.status !== filterValue)
          return false;
      }
      if (query) {
        const haystack = [
          delivery.siteName,
          delivery.driver,
          STATUS_LABEL[delivery.status] ?? delivery.status,
          dateFormat.format(new Date(delivery.plannedDate)),
          delivery.actualDate
            ? dateFormat.format(new Date(delivery.actualDate))
            : "",
          delivery.lagDays === null ? "" : String(delivery.lagDays),
        ]
          .join(" ")
          .toLowerCase();
        if (!haystack.includes(query)) return false;
      }
      return true;
    });
  }, [sortedDeliveries, filterField, filterValue, search]);

  const hasActiveFilters = !!(search || filterValue);

  function handleExport() {
    const rows = sortedDeliveries.map((delivery) => ({
      Объект: delivery.siteName,
      Водитель: delivery.driver,
      "Плановая дата": delivery.plannedDate.slice(0, 10),
    }));
    exportRowsToExcel(rows, TEMPLATE_HEADERS, "график-доставок.xlsx");
  }

  function openGenerateDialog() {
    if (!sites) return;
    const defaultDate = `${month}-05`;
    setScheduleRows(
      sites.map((site) => ({
        siteId: site.id,
        siteName: site.name,
        driver: site.driver,
        plannedDate: defaultDate,
      })),
    );
    setGenerateOpen(true);
  }

  function updateScheduleRow(siteId: string, patch: Partial<ScheduleRow>) {
    setScheduleRows((rows) =>
      rows.map((row) => (row.siteId === siteId ? { ...row, ...patch } : row)),
    );
  }

  function handleGenerateSubmit(e: React.FormEvent) {
    e.preventDefault();
    createBulk.mutate({
      data: {
        items: scheduleRows.map((row) => ({
          siteId: row.siteId,
          driver: row.driver,
          plannedDate: row.plannedDate,
        })),
      },
    });
  }

  function handleActualDateChange(delivery: Delivery, value: string) {
    updateDelivery.mutate({
      id: delivery.id,
      data: { actualDate: value || null },
    });
  }

  return (
    <div className="space-y-6">
      <h1
        className="text-2xl font-bold text-blue-900 bg-[#f5ecd9] rounded-md px-4 py-2 block w-full"
        data-testid="text-page-title"
      >
        График доставок
      </h1>
      <div className="flex items-center justify-between">
        <div>
          <p className="text-muted-foreground text-sm mt-1">
            Плановый график развоза по объектам, план-факт по датам
          </p>
        </div>
        <div className="flex items-center gap-2 flex-wrap justify-end">
          {canEditDeliveries && (
            <input
              ref={fileInputRef}
              type="file"
              accept=".xlsx,.xls,.csv"
              className="hidden"
              onChange={handleImportFile}
              data-testid="input-import-deliveries"
            />
          )}
          <Button
            variant="outline"
            onClick={() =>
              downloadTemplate(TEMPLATE_HEADERS, "шаблон-график-доставок.xlsx")
            }
            data-testid="button-download-template-deliveries"
          >
            <FileDown className="h-4 w-4 mr-2" />
            Выгрузить шаблон
          </Button>
          {canEditDeliveries && (
            <Button
              variant="outline"
              onClick={() => fileInputRef.current?.click()}
              disabled={createBulk.isPending}
              data-testid="button-import-deliveries"
            >
              <Upload className="h-4 w-4 mr-2" />
              Загрузить шаблон
            </Button>
          )}
          <Button
            variant="outline"
            onClick={handleExport}
            data-testid="button-export-deliveries"
          >
            <Download className="h-4 w-4 mr-2" />
            Выгрузить
          </Button>
          {canEditDeliveries && (
            <Button
              variant="outline"
              onClick={() => setLocation("/deliveries/run")}
              data-testid="button-delivery-run"
            >
              <ClipboardCheck className="h-4 w-4 mr-2" />
              Развоз за день
            </Button>
          )}
          {canEditDeliveries && (
            <Button
              onClick={openGenerateDialog}
              data-testid="button-generate-schedule"
            >
              <Plus className="h-4 w-4 mr-2" />
              Сформировать график на месяц
            </Button>
          )}
        </div>
      </div>

      <div className="flex items-center gap-3 flex-wrap">
        <div className="relative w-64">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Поиск по всем полям..."
            className="pl-8"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            data-testid="input-search-deliveries"
          />
        </div>
        <Popover
          open={periodPopoverOpen}
          onOpenChange={(open) => {
            setPeriodPopoverOpen(open);
            if (open) setDraftRange(dateRange);
          }}
        >
          <PopoverTrigger asChild>
            <Button variant="outline" data-testid="button-set-period">
              <CalendarRange className="h-4 w-4 mr-2" />
              Установить период: {periodLabel}
            </Button>
          </PopoverTrigger>
          <PopoverContent className="w-auto p-0" align="start">
            <div className="flex">
              <div className="flex flex-col gap-1 p-3 border-r">
                {(["day", "week", "month"] as const).map((preset) => (
                  <Button
                    key={preset}
                    variant={periodPreset === preset ? "default" : "ghost"}
                    size="sm"
                    className="justify-start"
                    onClick={() => applyPreset(preset)}
                    data-testid={`button-period-${preset}`}
                  >
                    {PERIOD_PRESET_LABEL[preset]}
                  </Button>
                ))}
                <div className="text-xs text-muted-foreground px-2 pt-2 pb-1">
                  Несколько дней
                </div>
                <Button
                  size="sm"
                  className="justify-start"
                  onClick={applyCustomRange}
                  disabled={!draftRange?.from}
                  data-testid="button-apply-custom-period"
                >
                  Применить выбор в календаре
                </Button>
              </div>
              <Calendar
                mode="range"
                locale={ru}
                selected={draftRange}
                onSelect={setDraftRange}
                numberOfMonths={2}
                defaultMonth={dateRange.from ?? new Date()}
              />
            </div>
          </PopoverContent>
        </Popover>
        <div className="flex items-center gap-0 border rounded-md">
          <Select
            value={filterField}
            onValueChange={(v) => {
              setFilterField(v as "site" | "driver" | "status");
              setFilterValue("");
            }}
          >
            <SelectTrigger
              className="w-36 border-0 rounded-r-none border-r"
              data-testid="select-filter-field"
            >
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="site">Объект</SelectItem>
              <SelectItem value="driver">Водитель</SelectItem>
              <SelectItem value="status">Статус</SelectItem>
            </SelectContent>
          </Select>
          {filterField === "site" ? (
            <Select
              value={filterValue || "all"}
              onValueChange={(v) => setFilterValue(v === "all" ? "" : v)}
            >
              <SelectTrigger
                className="w-48 border-0 rounded-l-none"
                data-testid="select-filter-value"
              >
                <SelectValue placeholder="Все объекты" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Все объекты</SelectItem>
                {sites?.map((site) => (
                  <SelectItem key={site.id} value={site.id}>
                    {site.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          ) : filterField === "status" ? (
            <Select
              value={filterValue || "all"}
              onValueChange={(v) => setFilterValue(v === "all" ? "" : v)}
            >
              <SelectTrigger
                className="w-48 border-0 rounded-l-none"
                data-testid="select-filter-value"
              >
                <SelectValue placeholder="Все статусы" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Все статусы</SelectItem>
                {Object.entries(STATUS_LABEL).map(([value, label]) => (
                  <SelectItem key={value} value={value}>
                    {label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          ) : (
            <Input
              placeholder="Введите водителя..."
              className="w-48 border-0 rounded-l-none"
              value={filterValue}
              onChange={(e) => setFilterValue(e.target.value)}
              data-testid="input-filter-value"
            />
          )}
        </div>
        {hasActiveFilters && (
          <Button
            variant="ghost"
            size="sm"
            onClick={() => {
              setSearch("");
              setFilterValue("");
            }}
            data-testid="button-reset-filters"
          >
            <X className="h-4 w-4 mr-1" />
            Сбросить фильтры
          </Button>
        )}
      </div>

      <div className="border rounded-md overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow>
              <SortableHeader
                field="siteName"
                label="Объект"
                sortField={sortField}
                sortDir={sortDir}
                onSort={handleSort}
              />
              <SortableHeader
                field="driver"
                label="Водитель"
                sortField={sortField}
                sortDir={sortDir}
                onSort={handleSort}
              />
              <SortableHeader
                field="plannedDate"
                label="План"
                sortField={sortField}
                sortDir={sortDir}
                onSort={handleSort}
              />
              <SortableHeader
                field="actualDate"
                label="Факт"
                sortField={sortField}
                sortDir={sortDir}
                onSort={handleSort}
              />
              <SortableHeader
                field="lagDays"
                label="Отклонение"
                sortField={sortField}
                sortDir={sortDir}
                onSort={handleSort}
              />
              <SortableHeader
                field="status"
                label="Статус"
                sortField={sortField}
                sortDir={sortDir}
                onSort={handleSort}
              />
              <TableHead className="w-16"></TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {isLoading ? (
              <TableRow>
                <TableCell
                  colSpan={7}
                  className="text-center text-muted-foreground py-8"
                >
                  Загрузка...
                </TableCell>
              </TableRow>
            ) : filteredDeliveries.length > 0 ? (
              filteredDeliveries.map((delivery) => (
                <TableRow
                  key={delivery.id}
                  data-testid={`row-delivery-${delivery.id}`}
                >
                  <TableCell className="font-medium whitespace-nowrap">
                    {delivery.siteName}
                  </TableCell>
                  <TableCell className="whitespace-nowrap">
                    <span className="inline-flex items-center gap-1 text-muted-foreground">
                      <Truck className="h-3.5 w-3.5" />
                      {delivery.driver}
                    </span>
                  </TableCell>
                  <TableCell className="whitespace-nowrap">
                    {dateFormat.format(new Date(delivery.plannedDate))}
                  </TableCell>
                  <TableCell className="whitespace-nowrap">
                    <Input
                      type="date"
                      className="h-8 w-36"
                      disabled={!canEditDeliveries}
                      value={
                        delivery.actualDate
                          ? toDateInputValue(delivery.actualDate)
                          : ""
                      }
                      onChange={(e) =>
                        handleActualDateChange(delivery, e.target.value)
                      }
                      data-testid={`input-actual-date-${delivery.id}`}
                    />
                  </TableCell>
                  <TableCell className="whitespace-nowrap text-muted-foreground">
                    {delivery.lagDays === null
                      ? "—"
                      : delivery.lagDays === 0
                        ? "0 дн."
                        : `${delivery.lagDays > 0 ? "+" : ""}${delivery.lagDays} дн.`}
                  </TableCell>
                  <TableCell>
                    <Badge
                      variant={
                        delivery.status === "on_time"
                          ? "outline"
                          : STATUS_VARIANT[delivery.status]
                      }
                      className={
                        delivery.status === "on_time"
                          ? "bg-green-100 text-green-800 hover:bg-green-100"
                          : undefined
                      }
                    >
                      {STATUS_LABEL[delivery.status]}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    {canEditDeliveries && (
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => setDeleteTarget(delivery)}
                        data-testid={`button-delete-delivery-${delivery.id}`}
                      >
                        <Trash2 className="h-4 w-4 text-destructive" />
                      </Button>
                    )}
                  </TableCell>
                </TableRow>
              ))
            ) : (
              <TableRow>
                <TableCell
                  colSpan={7}
                  className="text-center text-muted-foreground py-8"
                >
                  <div className="flex flex-col items-center gap-2">
                    <CalendarClock className="h-8 w-8 text-muted-foreground/50" />
                    На этот месяц график ещё не сформирован
                  </div>
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>

      <Dialog open={generateOpen} onOpenChange={setGenerateOpen}>
        <DialogContent className="max-w-2xl max-h-[85vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Сформировать график на {month}</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleGenerateSubmit} className="space-y-4">
            <p className="text-sm text-muted-foreground">
              Плановая дата фиксируется и не изменяется — далее вносится только
              факт доставки.
            </p>
            <div className="border rounded-md">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Объект</TableHead>
                    <TableHead>Водитель</TableHead>
                    <TableHead>Плановая дата</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {scheduleRows.map((row) => (
                    <TableRow key={row.siteId}>
                      <TableCell className="font-medium">
                        {row.siteName}
                      </TableCell>
                      <TableCell>
                        <Input
                          value={row.driver}
                          onChange={(e) =>
                            updateScheduleRow(row.siteId, {
                              driver: e.target.value,
                            })
                          }
                          data-testid={`input-schedule-driver-${row.siteId}`}
                        />
                      </TableCell>
                      <TableCell>
                        <Input
                          type="date"
                          value={row.plannedDate}
                          onChange={(e) =>
                            updateScheduleRow(row.siteId, {
                              plannedDate: e.target.value,
                            })
                          }
                          data-testid={`input-schedule-date-${row.siteId}`}
                        />
                      </TableCell>
                    </TableRow>
                  ))}
                  {scheduleRows.length === 0 && (
                    <TableRow>
                      <TableCell
                        colSpan={3}
                        className="text-center text-muted-foreground py-6"
                      >
                        Сначала добавьте объекты в справочник
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </div>
            <DialogFooter>
              <Button
                type="submit"
                disabled={createBulk.isPending || scheduleRows.length === 0}
                data-testid="button-submit-schedule"
              >
                Создать график
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      <AlertDialog
        open={!!deleteTarget}
        onOpenChange={(open) => !open && setDeleteTarget(null)}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Удалить запись графика?</AlertDialogTitle>
            <AlertDialogDescription>
              Доставка «{deleteTarget?.siteName}» на{" "}
              {deleteTarget
                ? dateFormat.format(new Date(deleteTarget.plannedDate))
                : ""}{" "}
              будет удалена без возможности восстановления.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Отмена</AlertDialogCancel>
            <AlertDialogAction
              onClick={() =>
                deleteTarget && deleteDelivery.mutate({ id: deleteTarget.id })
              }
              data-testid="button-confirm-delete-delivery"
            >
              Удалить
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
