import { Router, type IRouter } from "express";
import { and, eq, gte, lte, lt } from "drizzle-orm";
import { db, deliveriesTable, sitesTable } from "@workspace/db";
import {
  ListDeliveriesQueryParams,
  CreateDeliveryBody,
  CreateDeliveriesBulkBody,
  UpdateDeliveryParams,
  UpdateDeliveryBody,
  DeleteDeliveryParams,
  ListDeliveriesResponse,
  CreateDeliveryResponse,
  CreateDeliveriesBulkResponse,
  UpdateDeliveryResponse,
} from "@workspace/api-zod";
import { toDeliveryDto, monthRange } from "../lib/deliveries";
import { requirePermission } from "../middlewares/requirePermission";

const router: IRouter = Router();
const canEditDeliveries = requirePermission("deliveries");

router.get("/deliveries", async (req, res): Promise<void> => {
  const query = ListDeliveriesQueryParams.safeParse(req.query);
  if (!query.success) {
    res.status(400).json({ error: query.error.message });
    return;
  }

  const conditions = [];
  if (query.data.siteId) {
    conditions.push(eq(deliveriesTable.siteId, query.data.siteId));
  }
  if (query.data.driver) {
    conditions.push(eq(deliveriesTable.driver, query.data.driver));
  }
  if (query.data.dateFrom || query.data.dateTo) {
    if (query.data.dateFrom) {
      conditions.push(gte(deliveriesTable.plannedDate, query.data.dateFrom));
    }
    if (query.data.dateTo) {
      conditions.push(lte(deliveriesTable.plannedDate, query.data.dateTo));
    }
  } else if (query.data.month) {
    const { start, end } = monthRange(query.data.month);
    conditions.push(gte(deliveriesTable.plannedDate, start));
    conditions.push(lt(deliveriesTable.plannedDate, end));
  }

  const rows = await db
    .select({ delivery: deliveriesTable, siteName: sitesTable.name })
    .from(deliveriesTable)
    .innerJoin(sitesTable, eq(deliveriesTable.siteId, sitesTable.id))
    .where(conditions.length > 0 ? and(...conditions) : undefined)
    .orderBy(deliveriesTable.plannedDate);

  let dtos = rows.map((row) => toDeliveryDto(row.delivery, row.siteName));

  if (query.data.status) {
    dtos = dtos.filter((d) => d.status === query.data.status);
  }

  res.json(ListDeliveriesResponse.parse(dtos));
});

router.post("/deliveries", canEditDeliveries, async (req, res): Promise<void> => {
  const parsed = CreateDeliveryBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [site] = await db.select().from(sitesTable).where(eq(sitesTable.id, parsed.data.siteId));
  if (!site) {
    res.status(404).json({ error: "Site not found" });
    return;
  }

  const [delivery] = await db
    .insert(deliveriesTable)
    .values({
      siteId: parsed.data.siteId,
      driver: parsed.data.driver,
      plannedDate: parsed.data.plannedDate.toISOString().slice(0, 10),
      note: parsed.data.note ?? null,
    })
    .returning();

  res.status(201).json(CreateDeliveryResponse.parse(toDeliveryDto(delivery, site.name)));
});

router.post("/deliveries/bulk", canEditDeliveries, async (req, res): Promise<void> => {
  const parsed = CreateDeliveriesBulkBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const siteIds = [...new Set(parsed.data.items.map((item) => item.siteId))];
  const sites = await db.select().from(sitesTable);
  const siteMap = new Map(sites.map((s) => [s.id, s]));

  const missing = siteIds.filter((id) => !siteMap.has(id));
  if (missing.length > 0) {
    res.status(404).json({ error: `Sites not found: ${missing.join(", ")}` });
    return;
  }

  const inserted = await db
    .insert(deliveriesTable)
    .values(
      parsed.data.items.map((item) => ({
        siteId: item.siteId,
        driver: item.driver,
        plannedDate: item.plannedDate.toISOString().slice(0, 10),
        note: item.note ?? null,
      })),
    )
    .returning();

  const dtos = inserted.map((row) => toDeliveryDto(row, siteMap.get(row.siteId)!.name));

  res.status(201).json(CreateDeliveriesBulkResponse.parse(dtos));
});

router.patch("/deliveries/:id", canEditDeliveries, async (req, res): Promise<void> => {
  const params = UpdateDeliveryParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const parsed = UpdateDeliveryBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const updateValues: Record<string, unknown> = {};
  if (parsed.data.actualDate !== undefined) {
    updateValues.actualDate = parsed.data.actualDate
      ? parsed.data.actualDate.toISOString().slice(0, 10)
      : null;
  }
  if (parsed.data.note !== undefined) updateValues.note = parsed.data.note;

  const [delivery] = await db
    .update(deliveriesTable)
    .set(updateValues)
    .where(eq(deliveriesTable.id, params.data.id))
    .returning();

  if (!delivery) {
    res.status(404).json({ error: "Delivery not found" });
    return;
  }

  const [site] = await db.select().from(sitesTable).where(eq(sitesTable.id, delivery.siteId));

  res.json(UpdateDeliveryResponse.parse(toDeliveryDto(delivery, site?.name ?? "")));
});

router.delete("/deliveries/:id", canEditDeliveries, async (req, res): Promise<void> => {
  const params = DeleteDeliveryParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [delivery] = await db
    .delete(deliveriesTable)
    .where(eq(deliveriesTable.id, params.data.id))
    .returning();

  if (!delivery) {
    res.status(404).json({ error: "Delivery not found" });
    return;
  }

  res.sendStatus(204);
});

export default router;
