import type { NextFunction, Request, Response } from "express";
import type { Section } from "@workspace/db";

export function requirePermission(section: Section) {
  return (req: Request, res: Response, next: NextFunction): void => {
    const appUser = req.appUser;
    if (!appUser) {
      res.status(401).json({ error: "Unauthorized" });
      return;
    }

    if (appUser.role === "admin") {
      next();
      return;
    }

    if (appUser.role === "editor" && appUser.editableSections.includes(section)) {
      next();
      return;
    }

    res.status(403).json({ error: "Недостаточно прав для этого действия" });
  };
}

export function requireAdmin(req: Request, res: Response, next: NextFunction): void {
  if (req.appUser?.role !== "admin") {
    res.status(403).json({ error: "Требуются права администратора" });
    return;
  }
  next();
}
