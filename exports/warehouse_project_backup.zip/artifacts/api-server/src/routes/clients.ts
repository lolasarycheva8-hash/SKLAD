import { Router, type IRouter } from "express";
import { eq, ilike } from "drizzle-orm";
import { db, clientsTable, ordersTable } from "@workspace/db";
import {
  ListClientsQueryParams,
  CreateClientBody,
  DeleteClientParams,
  ListClientsResponse,
  CreateClientResponse,
} from "@workspace/api-zod";
import { requirePermission } from "../middlewares/requirePermission";

const router: IRouter = Router();
const canEditClients = requirePermission("clients");

function toClientDto(row: typeof clientsTable.$inferSelect) {
  return {
    id: row.id,
    name: row.name,
    contact: row.contact,
    createdAt: row.createdAt,
  };
}

router.get("/clients", async (req, res): Promise<void> => {
  const query = ListClientsQueryParams.safeParse(req.query);
  if (!query.success) {
    res.status(400).json({ error: query.error.message });
    return;
  }

  const rows = await db
    .select()
    .from(clientsTable)
    .where(query.data.search ? ilike(clientsTable.name, `%${query.data.search}%`) : undefined)
    .orderBy(clientsTable.name);

  res.json(ListClientsResponse.parse(rows.map(toClientDto)));
});

router.post("/clients", canEditClients, async (req, res): Promise<void> => {
  const parsed = CreateClientBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [client] = await db
    .insert(clientsTable)
    .values({
      name: parsed.data.name,
      contact: parsed.data.contact ?? null,
    })
    .returning();

  res.status(201).json(CreateClientResponse.parse(toClientDto(client)));
});

router.delete("/clients/:id", canEditClients, async (req, res): Promise<void> => {
  const params = DeleteClientParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [existingOrder] = await db
    .select({ id: ordersTable.id })
    .from(ordersTable)
    .where(eq(ordersTable.clientId, params.data.id));

  if (existingOrder) {
    res.status(409).json({ error: "Нельзя удалить клиента, у которого есть заказы" });
    return;
  }

  const [client] = await db
    .delete(clientsTable)
    .where(eq(clientsTable.id, params.data.id))
    .returning();

  if (!client) {
    res.status(404).json({ error: "Client not found" });
    return;
  }

  res.sendStatus(204);
});

export default router;
