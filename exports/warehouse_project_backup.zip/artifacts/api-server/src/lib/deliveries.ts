import { deliveriesTable } from "@workspace/db";

export type DeliveryStatus = "pending" | "on_time" | "late" | "overdue";

function todayISO(): string {
  return new Date().toISOString().slice(0, 10);
}

function daysBetween(from: string, to: string): number {
  return Math.round((new Date(to).getTime() - new Date(from).getTime()) / (1000 * 60 * 60 * 24));
}

export function computeStatus(
  plannedDate: string,
  actualDate: string | null,
): { status: DeliveryStatus; lagDays: number | null } {
  if (actualDate) {
    const lagDays = daysBetween(plannedDate, actualDate);
    return { status: lagDays > 0 ? "late" : "on_time", lagDays };
  }

  if (plannedDate < todayISO()) {
    return { status: "overdue", lagDays: daysBetween(plannedDate, todayISO()) };
  }

  return { status: "pending", lagDays: null };
}

export function toDeliveryDto(row: typeof deliveriesTable.$inferSelect, siteName: string) {
  const { status, lagDays } = computeStatus(row.plannedDate, row.actualDate);
  return {
    id: row.id,
    siteId: row.siteId,
    siteName,
    driver: row.driver,
    plannedDate: row.plannedDate,
    actualDate: row.actualDate,
    note: row.note,
    status,
    lagDays,
    createdAt: row.createdAt,
  };
}

export function monthRange(month: string): { start: string; end: string } {
  const [year, mon] = month.split("-").map(Number);
  const start = `${month}-01`;
  const end = new Date(Date.UTC(year, mon, 1)).toISOString().slice(0, 10);
  return { start, end };
}

export function currentMonth(): string {
  return todayISO().slice(0, 7);
}
